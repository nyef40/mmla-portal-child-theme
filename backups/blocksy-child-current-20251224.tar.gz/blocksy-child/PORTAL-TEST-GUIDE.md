# Portal System Test Guide

## Current Status (Dec 23, 2025)

Your system has the **OLD portal system working**, but you haven't visited any portal pages yet to verify.

## What You Have

1. **Portal template**: `page-portal-final.php` ✓ (created)
2. **Portal bundle**: `portal/dist/portal.js` (201KB) ✓ (built)
3. **Portal pages**: Created in WordPress database ✓
4. **Enqueue logic**: Active in functions.php ✓

## What's NOT Loaded

- `functions-react-unified.php` is created but NOT included in functions.php
- Unified React app at `react-app/dist/app.js` doesn't exist yet

## Test Steps

### Step 1: Verify Portal Pages Load

```bash
# Open browser and visit each URL:
http://localhost:8080/portal/
http://localhost:8080/portal-login/
http://localhost:8080/register/
http://localhost:8080/dashboard/
```

**Expected result**: 
- You should see `<div id="portal-root"></div>` in page source
- Portal navigation bar should appear
- Debug log should show: `Portal page detected: portal, enqueuing styles/scripts`

### Step 2: Check Browser Console

Press F12, go to Console tab. Look for:
```
Portal.js loaded
PortalNavigation mounted
```

If you see errors, paste them here.

### Step 3: Check Network Tab

Press F12, go to Network tab. Filter by "portal". You should see:
- `portal.js` (201KB) - Status 200
- `portal.css` (5.8KB) - Status 200

### Step 4: Check Debug Log

```bash
docker exec -it mmla-portal-wordpress-1 tail -f /var/www/html/wp-content/debug.log
```

Visit http://localhost:8080/portal/ and you should see:
```
Portal page detected: portal, enqueuing styles/scripts
Portal assets enqueued for page: portal
```

## Common Issues & Fixes

### Issue 1: Blank Page (No Portal UI)

**Cause**: `portal-root` div exists but React isn't mounting

**Fix**:
```bash
# Check if portal.js is actually loaded
curl -I http://localhost:8080/wp-content/themes/blocksy-child/portal/dist/portal.js

# Should return: HTTP/1.1 200 OK
```

### Issue 2: Only /portal/ Works, Other Pages Don't

**Cause**: Pages not created in WordPress database

**Fix**:
```bash
# Create missing pages
docker exec -it mmla-portal-wordpress-1 bash
wp post create --post_type=page --post_title='Dashboard' --post_name='dashboard' --post_status='publish' --allow-root
wp post create --post_type=page --post_title='Portal Login' --post_name='portal-login' --post_status='publish' --allow-root
wp post create --post_type=page --post_title='Register' --post_name='register' --post_status='publish' --allow-root
```

### Issue 3: WordPress Main Menu Shows Instead of Portal Menu

**Cause**: Portal.js not loading or React routing failing

**Fix**:
```bash
# Rebuild portal bundle
cd /Users/nikolayyefimov/Projects/mmla-portal/wordpress/wp-content/src
npm run build

# Verify bundle size
ls -lh ../themes/blocksy-child/portal/dist/portal.js
# Should be ~201KB
```

## Decision Point: Which System to Use?

You have TWO options:

### Option A: Keep Current Portal System (Recommended for Now)
- Portal pages work separately from main site
- Main site stays in WordPress/Elementor
- Portal is pure React
- **Action**: Just visit /portal/ to verify it works

### Option B: Migrate to Unified React App (Future)
- Entire site becomes React (main site + portal)
- Requires building unified app
- More complex migration
- **Action**: Follow unified React setup guide

## Next Steps After Testing

Once you verify /portal/ works:

1. Test login/register functionality
2. Test navigation between portal pages
3. Deploy to live (GoDaddy)
4. Then decide if you want unified React app
