# Portal Session Fix Guide

## Three Issues Fixed

### Issue 1: Nonce Verification Fails When Already Logged In
**Problem**: User logs in, then tries to log in again from portal home → "Security check failed"
**Root Cause**: Nonce is tied to old session token, new login creates new token
**Fix**: Skip nonce check in `portal_ajax_login_handler()` if user is already logged in

### Issue 2: Portal Home Page Logs Users Out
**Problem**: Visiting `/portal/` while logged in triggers automatic logout
**Root Cause**: Unknown logout trigger on portal home template
**Fix**: Added `remove_all_actions('wp_logout')` in `template_include` filter when on portal home

### Issue 3: Admin Redirect Conflict
**Problem**: Admin logs in via wp-login.php → gets redirected to `/dashboard/` instead of `/wp-admin/`
**Root Cause**: `login_redirect` filter always redirects portal users to dashboard
**Fix**: Check if login came from wp-login.php with wp-admin redirect_to parameter, allow admin access

## Deployment Steps

1. **Upload new session fix file**:
   ```bash
   scp functions-portal-auth-session-fix.php user@host:~/public_html/wp-content/themes/blocksy-child/
   ```

2. **Update functions.php**:
   - Add `require_once` for session fix BEFORE other auth files
   - This ensures session fix loads first

3. **Update auth-live-fix.php**:
   - Skip nonce check if already logged in
   - Fix admin redirect logic

4. **Update consolidation-fix.php**:
   - Prevent logout on portal home

5. **Test the fix**:
   ```bash
   # Test 1: Portal home doesn't log out
   curl -I -b cookies.txt https://mobilemedicalla.com/portal/
   
   # Test 2: Already-logged-in user can "log in" again
   # (Should return success without nonce error)
   
   # Test 3: Admin can access wp-admin
   # Go to wp-login.php, login as admin → should reach /wp-admin/
   ```

## Verification

After deployment, check debug.log for these messages:

```
[Portal Auth] User mmla2024 already logged in - returning success
[Portal Fix] Portal home accessed while logged in - preventing logout
[Portal Auth] Admin login detected via wp-login.php - allowing wp-admin access
```

## Rollback

If issues occur, remove the session fix:

```bash
ssh user@host
cd ~/public_html/wp-content/themes/blocksy-child
mv functions-portal-auth-session-fix.php functions-portal-auth-session-fix.php.bak
# Edit functions.php to remove the require_once line
wp cache flush --allow-root
