<?php
/**
 * Blocksy Child Theme Functions - FIXED VERSION
 * This file contains all the custom functionality for the portal system.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

date_default_timezone_set('America/Los_Angeles');

// Include portal authentication functions
$auth_file = get_stylesheet_directory() . '/functions-portal-auth-enhanced.php';
if (file_exists($auth_file)) {
    require_once $auth_file;
}

/**
 * Enqueue child theme styles
 */
function blocksy_child_enqueue_styles() {
    // Enqueue parent theme styles
    wp_enqueue_style('blocksy-parent-style', get_template_directory_uri() . '/style.css');
    
    // Enqueue child theme styles
    wp_enqueue_style('blocksy-child-style', get_stylesheet_directory_uri() . '/style.css', ['blocksy-parent-style']);
    
    // Enqueue portal CSS on portal pages only
    $portal_pages = ['portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact'];
    if (is_page($portal_pages) || strpos($_SERVER['REQUEST_URI'], '/portal') !== false || strpos($_SERVER['REQUEST_URI'], '/dashboard') !== false || strpos($_SERVER['REQUEST_URI'], '/register') !== false || strpos($_SERVER['REQUEST_URI'], '/contact') !== false) {
        wp_enqueue_style('portal-css', get_stylesheet_directory_uri() . '/portal/dist/portal.css', ['blocksy-child-style']);
        
        // Enqueue portal JavaScript
        wp_enqueue_script('portal-js', get_stylesheet_directory_uri() . '/portal/dist/portal.js', ['jquery'], '1.0', true);
        
        // Localize portal data
        wp_localize_script('portal-js', 'portalData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('portal_nonce'),
            'isLoggedIn' => is_user_logged_in(),
            'currentUser' => is_user_logged_in() ? wp_get_current_user() : null,
            'dashboardUrl' => home_url('/dashboard/'),
            'loginUrl' => home_url('/portal-login/'),
            'registerUrl' => home_url('/register/'),
            'logoutUrl' => wp_logout_url(home_url('/portal/')),
            'mainSiteUrl' => home_url('/')
        ]);
    }
}
add_action('wp_enqueue_scripts', 'blocksy_child_enqueue_styles');

/**
 * Add portal-specific body classes
 */
function add_portal_body_classes($classes) {
    $request_uri = $_SERVER['REQUEST_URI'];
    $portal_uris = ['/portal/', '/portal-login/', '/register/', '/dashboard/', '/portal-profile/', '/portal-resources/', '/portal-referrals/', '/contact/'];
    
    $is_portal_page = false;
    foreach ($portal_uris as $uri) {
        if (strpos($request_uri, rtrim($uri, '/')) !== false) {
            $is_portal_page = true;
            break;
        }
    }
    
    if ($is_portal_page || is_page(['portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact'])) {
        $classes[] = 'portal-page-active';
    }
    
    return $classes;
}
add_filter('body_class', 'add_portal_body_classes');

/**
 * Add portal header only on portal pages
 */
function add_portal_header() {
    $request_uri = $_SERVER['REQUEST_URI'];
    $portal_uris = ['/portal/', '/portal-login/', '/register/', '/dashboard/', '/portal-profile/', '/portal-resources/', '/portal-referrals/', '/contact/'];
    
    $is_portal_page = false;
    foreach ($portal_uris as $uri) {
        if (strpos($request_uri, rtrim($uri, '/')) !== false) {
            $is_portal_page = true;
            break;
        }
    }
    
    if ($is_portal_page || is_page(['portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact'])) {
        // Hide main site navigation
        add_action('wp_head', function() {
            echo '<style>
                body.portal-page-active .ct-header,
                body.portal-page-active .site-header,
                body.portal-page-active #masthead,
                body.portal-page-active .main-navigation,
                body.portal-page-active .ct-footer {
                    display: none !important;
                }
                
                body.portal-page-active .portal-header:not(:first-of-type) {
                    display: none !important;
                }
                
                body.portal-page-active {
                    padding-top: 0 !important;
                    margin-top: 0 !important;
                }
            </style>';
        }, 999);
        
        // Add portal header
        add_action('wp_body_open', function() {
            static $header_added = false;
            if ($header_added) return;
            $header_added = true;
            
            $current_uri = $_SERVER['REQUEST_URI'];
            ?>
            <div class="portal-header" style="background: linear-gradient(135deg, #0A3D62 0%, #1e5f8b 100%); padding: 15px 0; box-shadow: 0 4px 20px rgba(10, 61, 98, 0.3); position: sticky; top: 0; z-index: 9999;">
                <div class="portal-header-content" style="max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 0 20px;">
                    <a href="/portal/" class="portal-logo" style="color: white; font-size: 20px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 8px;">
                        🏥 Mobile Medical LA Portal
                    </a>
                    
                    <div class="portal-nav-menu" style="display: flex; gap: 15px; align-items: center;">
                        <a href="/portal/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Home</a>
                        
                        <?php if (is_user_logged_in()): ?>
                        <a href="/dashboard/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Dashboard</a>
                        <a href="/portal-profile/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Profile</a>
                        <a href="/portal-resources/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Resources</a>
                        <a href="/portal-referrals/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Referrals</a>
                        <a href="/contact/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Contact</a>
                        <a href="<?php echo wp_logout_url(home_url('/portal/')); ?>" class="portal-nav-item logout-btn" style="background: rgba(220, 53, 69, 0.8); color: white; text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Logout</a>
                        <?php else: ?>
                        <a href="/portal-login/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Login</a>
                        <a href="/register/" class="portal-nav-item" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Register</a>
                        <?php endif; ?>
                    </div>
                    
                    <a href="/" class="portal-back-btn" style="background: rgba(255, 255, 255, 0.2); color: white; padding: 10px 20px; border-radius: 20px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); font-size: 14px;">← Main Site</a>
                </div>
            </div>
            <?php
        }, 1);
    }
}
add_action('template_redirect', 'add_portal_header');

/**
 * Handle portal routing - SIMPLIFIED VERSION
 */
add_action('init', function() {
    // Add rewrite rules for portal pages
    add_rewrite_rule('^portal/?$', 'index.php?pagename=portal', 'top');
    add_rewrite_rule('^portal-login/?$', 'index.php?pagename=portal-login', 'top');
    add_rewrite_rule('^register/?$', 'index.php?pagename=register', 'top');
    add_rewrite_rule('^dashboard/?$', 'index.php?pagename=dashboard', 'top');
    add_rewrite_rule('^portal-profile/?$', 'index.php?pagename=portal-profile', 'top');
    add_rewrite_rule('^portal-resources/?$', 'index.php?pagename=portal-resources', 'top');
    add_rewrite_rule('^portal-referrals/?$', 'index.php?pagename=portal-referrals', 'top');
    add_rewrite_rule('^contact/?$', 'index.php?pagename=contact', 'top');
});

/**
 * Template redirect - SIMPLIFIED VERSION
 */
add_filter('template_include', function ($template) {
    if (is_page(['portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact'])) {
        $page_slug = get_post_field('post_name', get_post());
        $template_map = [
            'portal' => 'page-portal-final.php',
            'portal-login' => 'page-portal-login-enhanced.php',
            'register' => 'page-register-enhanced.php',
            'dashboard' => 'page-dashboard.php',
            'portal-profile' => 'page-profile.php',
            'portal-resources' => 'page-portal-resources.php',
            'portal-referrals' => 'page-portal-referrals.php',
            'contact' => 'page-contact.php'
        ];

        if (isset($template_map[$page_slug])) {
            $new_template = get_stylesheet_directory() . '/' . $template_map[$page_slug];
            if (file_exists($new_template)) {
                return $new_template;
            }
        }
    }

    return $template;
}, 99);

/**
 * Remove Blocksy header/footer on portal pages
 */
add_action('wp', function () {
    $pages = ['portal', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact', 'portal-login', 'register'];
    $page_ids = [1103, 820, 1697, 2328, 2327, 2361, 1700, 2335];
    
    if (is_page($pages) || in_array(get_queried_object_id(), $page_ids)) {
        remove_action('wp_footer', 'blocksy_output_footer', 10);
        remove_action('wp_head', 'blocksy_output_header', 10);
    }
});

/**
 * Create encryption key function
 */
if (!function_exists('get_encryption_key')) {
    function get_encryption_key() {
        $key = get_option('portal_encryption_key');
        if (!$key) {
            $key = wp_generate_password(32, false);
            update_option('portal_encryption_key', $key);
        }
        return $key;
    }
}

/**
 * WPForms referral handling
 */
function handle_referral_submission($fields, $entry, $form_data, $entry_id = null) {
    if ($form_data['id'] != 1479) {
        return $fields;
    }
    
    try {
        global $wpdb;
        $provider_name = isset($fields[2]['value']) ? sanitize_text_field($fields[2]['value']) : '';
        $provider_practice = isset($fields[14]['value']) ? sanitize_text_field($fields[14]['value']) : '';
        $provider_email = '';
        if (isset($fields[15]['value'])) {
            $provider_email = is_array($fields[15]['value']) ? sanitize_email($fields[15]['value']['primary']) : sanitize_email($fields[15]['value']);
        }
        $provider_phone = isset($fields[16]['value']) ? sanitize_text_field($fields[16]['value']) : '';
        $patient_name = isset($fields[18]['value']) ? sanitize_text_field($fields[18]['value']) : '';
        $patient_email = isset($fields[19]['value']) ? sanitize_email($fields[19]['value']) : '';
        $patient_phone = isset($fields[20]['value']) ? sanitize_text_field($fields[20]['value']) : '';
        $insurance = isset($fields[21]['value']) ? sanitize_text_field($fields[21]['value']) : '';
        $reason = isset($fields[23]['value']) ? sanitize_text_field($fields[23]['value']) : '';
        $notes = isset($fields[24]['value']) ? sanitize_textarea_field($fields[24]['value']) : '';
        
        $validation_token = wp_generate_uuid4();
        $encryption_key = get_encryption_key();
        $table_name = $wpdb->prefix . 'referral_submissions';
        
        $result = $wpdb->query($wpdb->prepare('INSERT INTO ' . $table_name . '
              (provider_name, provider_practice, provider_email, provider_phone,
               patient_name, patient_email, patient_phone, insurance,
               reason, notes, validation_token, is_validated, created_at)
             VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %s)',
            $provider_name, $provider_practice, $provider_email, $provider_phone,
            $patient_name, $patient_email, $patient_phone, $insurance,
            $reason, $notes, $validation_token, 0, current_time('mysql')
        ));
        
        if ($result !== false) {
            $submission_id = $wpdb->insert_id;
            $wpdb->query($wpdb->prepare("UPDATE {$table_name} SET
                  patient_name = AES_ENCRYPT(%s, %s),
                 patient_email = AES_ENCRYPT(%s, %s),
                 insurance = AES_ENCRYPT(%s, %s)
 WHERE submission_id = %d",
                $patient_name, $encryption_key,
                $patient_email, $encryption_key,
                $insurance, $encryption_key,
                $submission_id
            ));
        }
    } catch (Exception $e) {
        error_log('ERROR in referral processing: ' . $e->getMessage(), 3, WP_CONTENT_DIR . '/debug.log');
    }
    
    return $fields;
}
add_action('wpforms_process_complete', 'handle_referral_submission', 10, 4);

function handle_email_validation() {
    if (isset($_GET['action']) && $_GET['action'] === 'validate_email' && isset($_GET['token']) && isset($_GET['submission_id'])) {
        global $wpdb;
        $token = sanitize_text_field($_GET['token']);
        $submission_id = intval($_GET['submission_id']);
        $table_name = $wpdb->prefix . 'referral_submissions';
        
        $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE submission_id = %d AND validation_token = %s",
            $submission_id, $token
        ));
        
        if ($submission) {
            $wpdb->update($table_name,
                ['is_validated' => 1],
                ['submission_id' => $submission_id],
                ['%d'],
                ['%d']
            );
            wp_redirect(add_query_arg('validated', '1', home_url()));
            exit;
        } else {
            wp_die('Invalid or expired validation token.');
        }
    }
}
add_action('init', 'handle_email_validation');
