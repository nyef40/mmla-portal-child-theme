<?php
/**
 * Portal Auth Live Environment Fix
 * Ensures portal authentication works on GoDaddy/shared hosting
 */

add_action('init', 'portal_auth_intercept_live', 1); // Priority 1 = before most hooks

function portal_auth_intercept_live() {
    // Only intercept if we're on a portal auth page
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    
    // Check if this is a portal login attempt
    if (strpos($request_uri, '/portal-login/') !== false && $_SERVER['REQUEST_METHOD'] === 'POST') {
        portal_handle_login_request();
        exit; // Stop WordPress from handling it
    }
    
    // Check if this is a portal registration attempt
    if (strpos($request_uri, '/register/') !== false && $_SERVER['REQUEST_METHOD'] === 'POST') {
        portal_handle_register_request();
        exit; // Stop WordPress from handling it
    }
}

function portal_handle_login_request() {
    global $wpdb;
    
    $username = sanitize_text_field($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        wp_send_json_error(['message' => 'Username and password required']);
        return;
    }
    
    // Authenticate user
    $user = wp_authenticate($username, $password);
    
    if (is_wp_error($user)) {
        wp_send_json_error(['message' => $user->get_error_message()]);
        return;
    }
    
    // Log the user in
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, true);
    do_action('wp_login', $user->user_login, $user);
    
    // Update portal_users table
    $table_name = $wpdb->prefix . 'portal_users';
    $wpdb->update(
        $table_name,
        ['last_login' => current_time('mysql')],
        ['wp_user_id' => $user->ID]
    );
    
    wp_send_json_success([
        'message' => 'Login successful',
        'redirect' => home_url('/dashboard/')
    ]);
}

function portal_handle_register_request() {
    global $wpdb;
    
    $username = sanitize_text_field($_POST['username'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $first_name = sanitize_text_field($_POST['first_name'] ?? '');
    $last_name = sanitize_text_field($_POST['last_name'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    
    // Validate required fields
    if (empty($username) || empty($email) || empty($password)) {
        wp_send_json_error(['message' => 'Required fields missing']);
        return;
    }
    
    // Check if username or email already exists
    if (username_exists($username) || email_exists($email)) {
        wp_send_json_error(['message' => 'Username or email already exists']);
        return;
    }
    
    // Create WordPress user
    $user_id = wp_create_user($username, $password, $email);
    
    if (is_wp_error($user_id)) {
        wp_send_json_error(['message' => $user_id->get_error_message()]);
        return;
    }
    
    // Update user meta
    wp_update_user([
        'ID' => $user_id,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'display_name' => $first_name . ' ' . $last_name
    ]);
    
    // Add to portal_users table
    $table_name = $wpdb->prefix . 'portal_users';
    $wpdb->insert($table_name, [
        'wp_user_id' => $user_id,
        'username' => $username,
        'email' => $email,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'phone' => $phone,
        'created_at' => current_time('mysql'),
        'role' => 'user',
        'email_verified' => 0
    ]);
    
    // Auto-login the new user
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    
    wp_send_json_success([
        'message' => 'Registration successful',
        'redirect' => home_url('/portal/')
    ]);
}

add_filter('wp_debug_log_handler', 'portal_filter_debug_logs', 10, 4);

function portal_filter_debug_logs($message, $type, $file, $line) {
    // Suppress these noisy warnings
    $suppress_patterns = [
        '_load_textdomain_just_in_time',
        'Implicitly marking parameter',
        'Constant E_STRICT is deprecated',
        'Firebase\JWT\JWT::encode()',
        'ElementorPro\Modules\Forms'
    ];
    
    foreach ($suppress_patterns as $pattern) {
        if (strpos($message, $pattern) !== false) {
            return false; // Don't log this
        }
    }
    
    return $message; // Log everything else
}

function portal_is_live_environment() {
    $host = $_SERVER['HTTP_HOST'] ?? '';
    return strpos($host, 'mobilemedicalla.com') !== false;
}

function portal_is_local_environment() {
    $host = $_SERVER['HTTP_HOST'] ?? '';
    return strpos($host, 'localhost') !== false || strpos($host, '127.0.0.1') !== false;
}

function portal_log($message, $data = null) {
    if (!portal_is_live_environment()) {
        return; // Only log on live to track issues
    }
    
    $log_file = WP_CONTENT_DIR . '/portal-auth.log';
    $timestamp = date('Y-m-d H:i:s');
    $user_id = get_current_user_id();
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    
    $log_entry = sprintf(
        "[%s] User:%d | URI:%s | %s",
        $timestamp,
        $user_id,
        $request_uri,
        $message
    );
    
    if ($data) {
        $log_entry .= ' | Data: ' . json_encode($data);
    }
    
    $log_entry .= "\n";
    
    error_log($log_entry, 3, $log_file);
}

add_filter('portal_user_state', 'portal_fix_user_state_live', 10, 1);

function portal_fix_user_state_live($state) {
    if (!is_user_logged_in()) {
        return 'logged_out';
    }
    
    $user = wp_get_current_user();
    global $wpdb;
    
    $table_name = $wpdb->prefix . 'portal_users';
    $portal_user = $wpdb->get_row($wpdb->prepare(
        "SELECT * FROM {$table_name} WHERE wp_user_id = %d",
        $user->ID
    ));
    
    if (!$portal_user) {
        return 'logged_in_no_portal'; // WordPress user but not in portal
    }
    
    return 'logged_in_portal'; // Full portal user
}

add_action('wp_ajax_nopriv_portal_login', 'portal_ajax_login_handler');
add_action('wp_ajax_portal_login', 'portal_ajax_login_handler');

function portal_ajax_login_handler() {
    global $wpdb;
    
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        
        // Update last_login for already-logged-in user
        $table_name = $wpdb->prefix . 'portal_users';
        $wpdb->update(
            $table_name,
            ['last_login' => current_time('mysql')],
            ['wp_user_id' => $current_user->ID],
            ['%s'],
            ['%d']
        );
        
        error_log(sprintf(
            '[Portal Auth] User %s already logged in - returning success',
            $current_user->user_login
        ));
        
        wp_send_json_success([
            'message' => 'Already logged in',
            'redirect' => home_url('/dashboard/'),
            'user' => [
                'id' => $current_user->ID,
                'username' => $current_user->user_login,
                'email' => $current_user->user_email,
                'displayName' => $current_user->display_name
            ]
        ]);
        return;
    }
    
    // Verify nonce for non-logged-in users
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'portal_nonce')) {
        error_log(sprintf(
            '[Portal Auth] Nonce verification failed - nonce: %s, expected action: portal_nonce',
            $_POST['nonce'] ?? 'none'
        ));
        wp_send_json_error(['message' => 'Security check failed']);
        return;
    }
    
    $username = sanitize_text_field($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';
    
    if (empty($username) || empty($password)) {
        wp_send_json_error(['message' => 'Username and password required']);
        return;
    }
    
    // Authenticate user
    $user = wp_authenticate($username, $password);
    
    if (is_wp_error($user)) {
        wp_send_json_error(['message' => $user->get_error_message()]);
        return;
    }
    
    // Log the user in
    wp_set_current_user($user->ID);
    wp_set_auth_cookie($user->ID, true);
    do_action('wp_login', $user->user_login, $user);
    
    // Update portal_users table
    $table_name = $wpdb->prefix . 'portal_users';
    $wpdb->update(
        $table_name,
        ['last_login' => current_time('mysql')],
        ['wp_user_id' => $user->ID],
        ['%s'],
        ['%d']
    );
    
    wp_send_json_success([
        'message' => 'Login successful',
        'redirect' => home_url('/dashboard/'),
        'user' => [
            'id' => $user->ID,
            'username' => $user->user_login,
            'email' => $user->user_email,
            'displayName' => $user->display_name
        ]
    ]);
}

add_action('wp_ajax_nopriv_portal_register', 'portal_ajax_register_handler');
add_action('wp_ajax_portal_register', 'portal_ajax_register_handler');

function portal_ajax_register_handler() {
    // Verify nonce
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'portal_nonce')) {
        wp_send_json_error(['message' => 'Security check failed']);
        return;
    }
    
    global $wpdb;
    
    $username = sanitize_text_field($_POST['username'] ?? '');
    $email = sanitize_email($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';
    $first_name = sanitize_text_field($_POST['first_name'] ?? '');
    $last_name = sanitize_text_field($_POST['last_name'] ?? '');
    $phone = sanitize_text_field($_POST['phone'] ?? '');
    
    // Validate required fields
    if (empty($username) || empty($email) || empty($password)) {
        wp_send_json_error(['message' => 'Required fields missing']);
        return;
    }
    
    // Check if username or email already exists
    if (username_exists($username)) {
        wp_send_json_error(['message' => 'Username already exists']);
        return;
    }
    
    if (email_exists($email)) {
        wp_send_json_error(['message' => 'Email already exists']);
        return;
    }
    
    // Create WordPress user
    $user_id = wp_create_user($username, $password, $email);
    
    if (is_wp_error($user_id)) {
        wp_send_json_error(['message' => $user_id->get_error_message()]);
        return;
    }
    
    // Update user meta
    wp_update_user([
        'ID' => $user_id,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'display_name' => trim($first_name . ' ' . $last_name)
    ]);
    
    // Add to portal_users table
    $table_name = $wpdb->prefix . 'portal_users';
    $wpdb->insert($table_name, [
        'wp_user_id' => $user_id,
        'username' => $username,
        'email' => $email,
        'first_name' => $first_name,
        'last_name' => $last_name,
        'phone' => $phone,
        'created_at' => current_time('mysql'),
        'role' => 'user',
        'email_verified' => 0
    ]);
    
    // Auto-login the new user
    wp_set_current_user($user_id);
    wp_set_auth_cookie($user_id, true);
    do_action('wp_login', $username, get_user_by('id', $user_id));
    
    wp_send_json_success([
        'message' => 'Registration successful',
        'redirect' => home_url('/portal/'),
        'user' => [
            'id' => $user_id,
            'username' => $username,
            'email' => $email,
            'displayName' => trim($first_name . ' ' . $last_name)
        ]
    ]);
}

add_filter('login_redirect', 'portal_override_login_redirect', 999, 3);

function portal_override_login_redirect($redirect_to, $request, $user) {
    // Check if this login came from portal
    $referer = wp_get_referer();
    
    // Check if this is an explicit wp-admin login attempt
    if (strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false) {
        // Check if user tried to access wp-admin directly
        if (isset($_POST['redirect_to']) && strpos($_POST['redirect_to'], 'wp-admin') !== false) {
            error_log('[Portal Auth] Admin login detected via wp-login.php - allowing wp-admin access');
            return admin_url();
        }
    }
    
    // Check if login came from portal
    if ($referer && (strpos($referer, '/portal') !== false || strpos($referer, '/dashboard') !== false)) {
        error_log('[Portal Auth] Portal login detected - redirecting to dashboard');
        return home_url('/dashboard/');
    }
    
    // Check if user is a portal user (has entry in portal_users table)
    if (is_a($user, 'WP_User')) {
        global $wpdb;
        $table_name = $wpdb->prefix . 'portal_users';
        $portal_user = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$table_name} WHERE wp_user_id = %d",
            $user->ID
        ));
        
        // Only redirect portal users to dashboard if they're not admins accessing wp-admin
        if ($portal_user && !user_can($user, 'manage_options')) {
            error_log('[Portal Auth] Portal user login - redirecting to dashboard');
            return home_url('/dashboard/');
        }
    }
    
    // Default: let WordPress handle the redirect
    error_log('[Portal Auth] Standard login - using default redirect');
    return $redirect_to;
}

add_action('template_redirect', 'portal_catch_internal_routes', 1);

function portal_catch_internal_routes() {
    $request_uri = $_SERVER['REQUEST_URI'] ?? '';
    
    // Define portal internal routes (React handles these client-side)
    $portal_routes = [
        '/dashboard/',
        '/portal-profile/',
        '/portal-resources/',
        '/portal-referrals/',
        '/portal-login/',
        '/register/'
    ];
    
    foreach ($portal_routes as $route) {
        if (strpos($request_uri, $route) !== false) {
            $portal_template = get_stylesheet_directory() . '/page-portal-final.php';
            
            if (file_exists($portal_template)) {
                status_header(200);
                include $portal_template;
                exit;
            } else {
                // Fallback to parent theme template
                $portal_template_parent = get_template_directory() . '/page-portal-final.php';
                if (file_exists($portal_template_parent)) {
                    status_header(200);
                    include $portal_template_parent;
                    exit;
                }
            }
        }
    }
}
