<?php
/**
 * Portal Authentication Session Fix
 * Resolves conflicts between portal auth and WordPress admin auth
 */

if (!defined('ABSPATH')) {
    exit;
}

add_filter('wp_ajax_portal_login', 'fix_portal_login_nonce_validation', 1);
add_filter('wp_ajax_nopriv_portal_login', 'fix_portal_login_nonce_validation', 1);

function fix_portal_login_nonce_validation() {
    // If user is already logged in, skip nonce check and just return success
    if (is_user_logged_in()) {
        $current_user = wp_get_current_user();
        
        error_log(sprintf(
            '[Portal Auth Fix] User already logged in: %s (ID: %d)',
            $current_user->user_login,
            $current_user->ID
        ));
        
        wp_send_json_success([
            'message' => 'Already logged in',
            'redirect' => home_url('/dashboard/')
        ]);
        exit;
    }
}

add_action('template_redirect', 'prevent_portal_home_logout', 5);

function prevent_portal_home_logout() {
    // Check if we're on the portal home page
    if (is_page('portal')) {
        // If user is logged in, do NOT trigger any logout
        if (is_user_logged_in()) {
            error_log('[Portal Auth Fix] Portal home accessed while logged in - preventing logout');
            
            // Remove any logout hooks that might be triggered
            remove_all_actions('wp_logout');
            
            // If there's a logout parameter in URL, remove it
            if (isset($_GET['action']) && $_GET['action'] === 'logout') {
                wp_safe_redirect(home_url('/portal/'));
                exit;
            }
        }
    }
}

add_filter('login_redirect', 'fix_admin_portal_redirect', 20, 3);

function fix_admin_portal_redirect($redirect_to, $requested_redirect, $user) {
    if (is_wp_error($user)) {
        return $redirect_to;
    }
    
    // Check if user is admin
    if (user_can($user, 'manage_options')) {
        // If they explicitly requested wp-admin, let them go there
        if (strpos($requested_redirect, 'wp-admin') !== false || 
            strpos($_SERVER['REQUEST_URI'], 'wp-login.php') !== false) {
            
            error_log(sprintf(
                '[Portal Auth Fix] Admin login detected - allowing wp-admin access for user %s',
                $user->user_login
            ));
            
            return admin_url();
        }
    }
    
    // For non-admin portal users, redirect to dashboard
    if (isset($_POST['action']) && $_POST['action'] === 'portal_login') {
        return home_url('/dashboard/');
    }
    
    return $redirect_to;
}

add_filter('wp_create_nonce', 'fix_portal_nonce_generation', 10, 2);

function fix_portal_nonce_generation($nonce, $action) {
    // For portal login nonce, make it work across sessions
    if ($action === 'portal_login_nonce') {
        // Use a combination of user ID + time + salt that doesn't depend on session token
        $user_id = get_current_user_id();
        $tick = ceil(time() / (DAY_IN_SECONDS / 2));
        
        // Generate nonce that works for 12 hours regardless of session changes
        $nonce = substr(
            hash_hmac('sha256', $tick . '|portal_login_nonce|' . $user_id, wp_salt('nonce')),
            -12,
            10
        );
        
        error_log(sprintf(
            '[Portal Auth Fix] Generated session-independent nonce: %s for user %d',
            $nonce,
            $user_id
        ));
    }
    
    return $nonce;
}

add_filter('verify_nonce_action', 'fix_portal_nonce_verification', 10, 3);

function fix_portal_nonce_verification($action, $nonce, $user_id) {
    if ($action === 'portal_login_nonce') {
        // Regenerate the nonce with the same logic
        $tick = ceil(time() / (DAY_IN_SECONDS / 2));
        $expected_nonce = substr(
            hash_hmac('sha256', $tick . '|portal_login_nonce|' . $user_id, wp_salt('nonce')),
            -12,
            10
        );
        
        // Also check previous tick (for edge cases)
        $prev_tick = $tick - 1;
        $expected_nonce_prev = substr(
            hash_hmac('sha256', $prev_tick . '|portal_login_nonce|' . $user_id, wp_salt('nonce')),
            -12,
            10
        );
        
        $is_valid = ($nonce === $expected_nonce || $nonce === $expected_nonce_prev);
        
        error_log(sprintf(
            '[Portal Auth Fix] Nonce verification: %s (expected: %s or %s) - Result: %s',
            $nonce,
            $expected_nonce,
            $expected_nonce_prev,
            $is_valid ? 'PASS' : 'FAIL'
        ));
        
        return $is_valid ? $action : false;
    }
    
    return $action;
}

add_action('init', 'separate_portal_admin_sessions');

function separate_portal_admin_sessions() {
    // Set portal-specific cookie when on portal pages
    if (is_user_logged_in()) {
        $portal_pages = ['portal', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'portal-login'];
        
        $current_page = get_query_var('pagename');
        if (!$current_page) {
            $current_page = get_post_field('post_name', get_the_ID());
        }
        
        if (in_array($current_page, $portal_pages)) {
            // Set a cookie to track portal session
            if (!isset($_COOKIE['portal_session'])) {
                setcookie('portal_session', '1', time() + DAY_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
            }
        }
    }
}

error_log('[Portal Auth Fix] Session fix loaded - nonce generation now session-independent');
