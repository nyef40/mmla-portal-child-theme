<?php
/**
 * Portal Page Consolidation Fix
 * 
 * PROBLEM: Portal pages can't be edited in Elementor because template files have hardcoded content
 * SOLUTION: Separate "public pages" from "portal app pages"
 * 
 * PUBLIC PAGES (WordPress-editable):
 * - /resources/ → Normal WordPress page (ID 50046) with Elementor blocks
 * - /about-us/, /partners/, /our-services/ → Normal WordPress pages
 * 
 * PORTAL APP PAGES (React-based, programmatic):
 * - /portal/ → Main app entry point (loads portal.js)
 * - /dashboard/, /portal-profile/, /portal-resources/, /portal-referrals/ → React client-side routes
 * - /portal-login/, /register/ → Portal auth pages (React or template-based)
 */

if (!defined('ABSPATH')) {
    exit;
}

if (defined('PORTAL_CONSOLIDATION_FIX_LOADED')) {
    return;
}
define('PORTAL_CONSOLIDATION_FIX_LOADED', true);

/**
 * STEP 1: Fix Public "Resources" Page
 * Remove custom template so it uses default (Elementor-editable)
 * 
 * RUN MANUALLY:
 * wp post list --post_type=page --search='Resources' --format=ids --allow-root
 * wp post meta delete 50046 '_wp_page_template --allow-root
 */
function fix_public_resources_page() {
    // Find the public "Resources" page
    $resource_page = get_page_by_path('resources');
    
    if ($resource_page) {
        $page_template = get_page_template_slug($resource_page->ID);
        
        // If it has a custom template (page-resources.php), remove it
        if (!empty($page_template)) {
            delete_post_meta($resource_page->ID, '_wp_page_template');
            error_log("[Portal Fix] ✓ Removed custom template from Resources (ID: {$resource_page->ID})");
            error_log("[Portal Fix] Resources page now uses default template - edit in Elementor");
        }
    }
}

/**
 * STEP 2: Ensure Portal App Entry Point Exists
 * Only ONE page needed: /portal/ - all other routes are React client-side
 */
function ensure_portal_app_entry_exists() {
    $portal_page = get_page_by_path('portal');
    
    if (!$portal_page) {
        $portal_id = wp_insert_post([
            'post_title'   => 'Portal',
            'post_name'    => 'portal',
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_content' => '<div id="portal-root"></div><!-- React app mounts here -->'
        ]);
        
        if ($portal_id) {
            error_log("[Portal Fix] ✓ Created Portal app entry page (ID: {$portal_id})");
        }
    } else {
        error_log("[Portal Fix] ✓ Portal app entry page exists (ID: {$portal_page->ID})");
    }
}

/**
 * STEP 3: Clean Up Internal Portal Pages
 * These pages should NOT be edited in WordPress - they're just routing anchors
 * /dashboard/, /portal-profile/, /portal-resources/, /portal-referrals/ are handled by React
 */
function mark_internal_portal_pages_as_readonly() {
    $internal_portal_slugs = [
        'dashboard',
        'portal-profile',
        'portal-resources',
        'portal-referrals',
        'portal-login',
        'register'
    ];
    
    foreach ($internal_portal_slugs as $slug) {
        $page = get_page_by_path($slug);
        
        if ($page) {
            // Add a custom meta to mark this as internal
            update_post_meta($page->ID, '_is_portal_internal', 'true');
            error_log("[Portal Fix] ✓ Marked {$slug} as internal portal page (ID: {$page->ID})");
        }
    }
}

/**
 * STEP 4: Template Routing Fix
 * Determine which template to use based on page slug
 */
add_filter('template_include', function($template) {
    if (!is_singular('page')) {
        return $template;
    }
    
    $current_slug = get_post_field('post_name', get_the_ID());
    
    if ($current_slug === 'portal' && is_user_logged_in()) {
        error_log('[Portal Fix] Portal home accessed while logged in - preventing logout');
        
        // Remove any logout actions that might trigger
        remove_all_actions('wp_logout');
        
        // If there's a logout parameter, strip it
        if (isset($_GET['action']) && $_GET['action'] === 'logout') {
            wp_safe_redirect(remove_query_arg('action'));
            exit;
        }
    }
    
    // Portal app pages - use portal app template
    $portal_app_pages = ['portal', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'portal-login', 'register'];
    
    if (in_array($current_slug, $portal_app_pages)) {
        $portal_template = get_stylesheet_directory() . '/page-portal-final.php';
        
        if (file_exists($portal_template)) {
            return $portal_template;
        }
        
        // Fallback to parent theme
        $portal_template_parent = get_template_directory() . '/page-portal-final.php';
        if (file_exists($portal_template_parent)) {
            return $portal_template_parent;
        }
    }
    
    // Public pages - use default theme template (Elementor-compatible)
    if (in_array($current_slug, ['resources', 'about-us', 'partners', 'our-services'])) {
        return $template; // Use default template
    }
    
    return $template;
}, 10, 1);

/**
 * STEP 5: Admin Notice for Internal Pages
 * Warn editors not to edit internal portal pages
 */
add_action('admin_notices', function() {
    if (!is_admin()) {
        return;
    }
    
    global $post;
    if (!$post) {
        return;
    }
    
    $is_internal = get_post_meta($post->ID, '_is_portal_internal', true);
    
    if ($is_internal === 'true') {
        ?>
        <div class="notice notice-warning">
            <p><strong>🔒 Portal Internal Page:</strong> This page is part of the Portal React app. Changes here won't appear to users. To modify this page's content, edit the React component at <code>/portal/src/pages/</code> or contact the developer.</p>
        </div>
        <?php
    }
});

/**
 * STEP 6: Run Setup on Admin Init
 */
add_action('admin_init', function() {
    if (current_user_can('manage_options')) {
        fix_public_resources_page();
        ensure_portal_app_entry_exists();
        mark_internal_portal_pages_as_readonly();
        
        // Only log once per page load
        error_log("[Portal Fix] ✓ Portal consolidation checks completed");
    }
});

/**
 * STEP 7: Debug Helper
 * Add ?debug_portal=1 to any page to see routing details
 */
add_action('wp_footer', function() {
    if (current_user_can('manage_options') && isset($_GET['debug_portal'])) {
        global $post;
        $internal = get_post_meta($post->ID, '_is_portal_internal', true);
        $template = get_page_template_slug($post->ID);
        
        echo '<div style="background:#f0f0f0;padding:20px;margin-top:40px;font-family:monospace;border-top:3px solid #0A3D62;">';
        echo '<strong>Portal Debug Info:</strong><br>';
        echo "Page ID: {$post->ID}<br>";
        echo "Page Slug: {$post->post_name}<br>";
        echo "Template: {$template}<br>";
        echo "Internal Portal Page: " . ($internal ? 'YES' : 'NO') . "<br>";
        echo "Is Logged In: " . (is_user_logged_in() ? 'YES' : 'NO') . "<br>";
        echo '</div>';
    }
});

add_filter('doing_it_wrong_trigger_error', function($trigger, $function_name, $message) {
    // Suppress specific noisy warnings on live
    $suppress_functions = [
        '_load_textdomain_just_in_time',
    ];
    
    if (in_array($function_name, $suppress_functions)) {
        return false; // Don't trigger error
    }
    
    return $trigger;
}, 10, 3);

if (defined('WP_DEBUG') && WP_DEBUG) {
    error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_STRICT);
}

