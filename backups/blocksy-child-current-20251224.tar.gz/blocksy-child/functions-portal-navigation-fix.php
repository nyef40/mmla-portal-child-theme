<?php
/**
 * Portal Navigation Fixes - Stronger CSS to Hide Main Navigation and Enhanced Portal Header
 */

// Prevent direct access and multiple inclusions
if (!defined('ABSPATH')) {
    exit;
}
if (!defined('PORTAL_NAVIGATION_FIXES_LOADED')) {
    define('PORTAL_NAVIGATION_FIXES_LOADED', true);
} else {
    return;
}

/**
 * Add custom body classes for portal pages for easier CSS targeting
 */
add_filter('body_class', function ($classes) {
    // List of all portal-related pages
    $portal_pages = [
        'portal',
        'portal-login',
        'register', // 'register' is also part of the portal flow
        'dashboard',
        'portal-profile',
        'portal-resources',
        'portal-referrals'
    ];

    // Get the current page slug
    $current_slug = get_post_field('post_name', get_post());

    // Check if the current page is one of the portal pages
    if (in_array($current_slug, $portal_pages)) {
        $classes[] = 'portal-page-active'; // Add a general class for all portal pages
        $classes[] = 'portal-page-' . $current_slug; // Add a specific class for each portal page
    }
    return $classes;
});

/**
 * Hide main navigation with nuclear CSS approach
 */
function hide_main_navigation_nuclear() {
    $portal_pages = ['portal', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'portal-login', 'register']; // Added 'register'
    
    if (is_page($portal_pages)) {

        error_log("hide_main_navigation_nuclear for page: " . get_post_field('post_name', get_post()) . ", is_user_logged_in: " . (is_user_logged_in() ? 'true' : 'false'));

        add_action('wp_head', function() {
            echo '<style>
                /* NUCLEAR APPROACH - Hide ALL possible navigation elements */
                .site-header nav,
                .site-header .nav,
                .site-header .navigation,
                .site-header .main-navigation,
                .site-header .primary-navigation,
                .site-header .header-menu,
                .site-header .menu,
                .site-header ul.menu,
                .site-header .nav-menu,
                .site-header .primary-menu,
                .site-header .main-menu,
                .site-header .navigation-menu,
                .site-header .header-navigation,
                #site-navigation,
                #primary-navigation,
                #main-navigation,
                .header-menu-wrap,
                .menu-main-menu-container,
                .menu-primary-container,
                [data-id="menu"],
                [class*="menu"],
                [class*="nav"]:not(.portal-nav):not(.portal-nav-menu):not(.portal-nav-item),
                .ct-header-cta,
                .header-button,
                .ct-toggle-dropdown-desktop {
                    display: none !important;
                    visibility: hidden !important;
                    opacity: 0 !important;
                    height: 0 !important;
                    overflow: hidden !important;
                }
                
                /* Force hide with JavaScript backup */
                body.portal-page .site-header nav,
                body.portal-page .site-header .menu {
                    display: none !important;
                }
                
                /* Style the header for portal */
                .site-header {
                    background: linear-gradient(135deg, #0A3D62 0%, #1e5f8b 100%) !important;
                    box-shadow: 0 4px 20px rgba(10, 61, 98, 0.3) !important;
                    min-height: 60px !important;
                    padding: 10px 0 !important;
                }
                
                /* Hide breadcrumbs and page titles */
                .breadcrumbs,
                .breadcrumb,
                .entry-header,
                .page-title,
                .entry-title {
                    display: none !important;
                }
                
                /* Full width content */
                .content-area,
                .site-main,
                .entry-content {
                    max-width: 100% !important;
                    padding: 0 !important;
                    margin: 0 !important;
                }
                
                /* Remove default page styling */
                .page .entry-content {
                    background: none !important;
                    box-shadow: none !important;
                    border: none !important;
                }
                
                /* Add body class for portal pages */
                body {
                    --portal-active: true;
                }
            </style>';
        }, 1); // High priority
        
        // Add body class via JavaScript as backup
        add_action('wp_footer', function() {
            echo '<script>
                document.body.classList.add("portal-page");
                
                // Nuclear JavaScript approach - hide any remaining navigation
                document.addEventListener("DOMContentLoaded", function() {
                    const selectors = [
                        ".site-header nav",
                        ".site-header .menu",
                        ".site-header .navigation",
                        ".main-navigation",
                        ".primary-navigation",
                        ".header-menu"
                    ];
                    
                    selectors.forEach(selector => {
                        const elements = document.querySelectorAll(selector);
                        elements.forEach(el => {
                            if (!el.classList.contains("portal-nav") && !el.closest(".portal-header")) {
                                el.style.display = "none";
                                el.style.visibility = "hidden";
                                el.style.opacity = "0";
                            }
                        });
                    });
                });
            </script>';
        });
    }
}
add_action('template_redirect', 'hide_main_navigation_nuclear', 1);

/**
 * Enhanced Portal Header - Only show on portal pages
 */
function add_portal_header_only() {
    $portal_pages = ['portal', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'portal-login', 'register']; // Include login/register for header
    
    if (is_page($portal_pages)) {
        add_action('wp_head', function() {
            echo '<style>
                .portal-header {
                    background: linear-gradient(135deg, #0A3D62 0%, #1e5f8b 100%);
                    padding: 15px 0;
                    box-shadow: 0 4px 20px rgba(10, 61, 98, 0.3);
                    position: sticky;
                    top: 0;
                    z-index: 9999;
                    margin: 0;
                }
                
                .portal-header-content {
                    max-width: 1200px;
                    margin: 0 auto;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    padding: 0 20px;
                }
                
                .portal-logo {
                    color: white;
                    font-size: 20px;
                    font-weight: 700;
                    text-decoration: none;
                    display: flex;
                    align-items: center;
                    gap: 8px;
                }
                
                .portal-nav-menu {
                    display: flex;
                    gap: 15px;
                    align-items: center;
                }
                
                .portal-nav-item {
                    color: rgba(255, 255, 255, 0.8);
                    text-decoration: none;
                    padding: 8px 16px;
                    border-radius: 20px;
                    transition: all 0.3s ease;
                    font-weight: 500;
                    font-size: 14px;
                }
                
                .portal-nav-item:hover,
                .portal-nav-item.active {
                    background: rgba(255, 255, 255, 0.2);
                    color: white;
                    transform: translateY(-1px);
                }
                
                .portal-back-btn {
                    background: rgba(255, 255, 255, 0.2);
                    color: white;
                    padding: 10px 20px;
                    border-radius: 20px;
                    text-decoration: none;
                    font-weight: 600;
                    transition: all 0.3s ease;
                    backdrop-filter: blur(10px);
                    border: 1px solid rgba(255, 255, 255, 0.3);
                    font-size: 14px;
                }
                
                .portal-back-btn:hover {
                    background: rgba(255, 255, 255, 0.3);
                    transform: translateY(-2px);
                    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.2);
                    color: white;
                }
                
                @media (max-width: 768px) {
                    .portal-nav-menu {
                        display: none;
                    }
                    
                    .portal-header-content {
                        flex-direction: column;
                        gap: 10px;
                        padding: 10px 20px;
                    }
                    
                    .portal-logo {
                        font-size: 18px;
                    }
                    
                    .portal-back-btn {
                        font-size: 13px;
                        padding: 8px 16px;
                    }
                }
            </style>';
        }, 1);
        
        add_action('wp_body_open', function() {
            $current_page = get_post_field('post_name', get_post());
            $is_logged_in = is_user_logged_in();
            error_log("Portal header, is_user_logged_in: " . ($is_logged_in ? 'true' : 'false'));
            echo '<div class="portal-header">
                <div class="portal-header-content">
                    <a href="/portal/" class="portal-logo">
                        🏥 Mobile Medical LA Portal
                    </a>';
            if ($is_logged_in) {
                echo '<div class="portal-nav-menu">
                    <a href="/portal/" class="portal-nav-item ' . ($current_page === 'portal' ? 'active' : '') . '">Home</a>
                    <a href="/dashboard/" class="portal-nav-item ' . ($current_page === 'dashboard' ? 'active' : '') . '">Dashboard</a>
                    <a href="/portal-profile/" class="portal-nav-item ' . ($current_page === 'portal-profile' ? 'active' : '') . '">Profile</a>
                    <a href="/portal-resources/" class="portal-nav-item ' . ($current_page === 'portal-resources' ? 'active' : '') . '">Resources</a>
                    <a href="/portal-referrals/" class="portal-nav-item ' . ($current_page === 'portal-referrals' ? 'active' : '') . '">Referrals</a>
                    <a href="' . wp_logout_url(home_url('/portal/')) . '" class="portal-nav-item">Logout</a>
                </div>';
            } else {
                echo '<div class="portal-nav-menu">
                    <a href="/portal-login/" class="portal-nav-item ' . ($current_page === 'portal-login' ? 'active' : '') . '">Login</a>
                    <a href="/register/" class="portal-nav-item ' . ($current_page === 'register' ? 'active' : '') . '">Register</a>
                </div>';
            }
            echo '<a href="/" class="portal-back-btn">← Main Site</a>
                </div>
            </div>';
        });
    }
}
add_action('template_redirect', 'add_portal_header_only', 1);

/**
 * Enqueue a small inline script to ensure main site navigation is hidden
 * This acts as a fallback if CSS is not strong enough or loaded late.
 */
add_action('wp_head', function() {
    // Check if we are on a portal page
    $portal_pages = [
        'portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals'
    ];
    $current_slug = get_post_field('post_name', get_post());

    if (in_array($current_slug, $portal_pages)) {
        ?>
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Select common main navigation elements by their IDs or classes
                const mainNavSelectors = [
                    '#main-header', // Common header ID
                    '#main-navigation', // Common navigation ID
                    '.site-header', // Common header class
                    '.main-navigation', // Common navigation class
                    '.ct-header-builder', // Blocksy specific header builder
                    '.ct-footer-builder', // Blocksy specific footer builder
                    '#masthead', // Another common header ID
                    '.ct-header', // Blocksy header
                    '.ct-footer', // Blocksy footer
                    // Add more selectors if your theme uses different ones
                ];

                mainNavSelectors.forEach(selector => {
                    document.querySelectorAll(selector).forEach(el => {
                        el.style.setProperty('display', 'none', 'important');
                        el.style.setProperty('visibility', 'hidden', 'important');
                        el.style.setProperty('width', '0', 'important');
                        el.style.setProperty('height', '0', 'important');
                        el.style.setProperty('overflow', 'hidden', 'important');
                        el.style.setProperty('position', 'absolute', 'important');
                        el.style.setProperty('left', '-9999px', 'important');
                        el.style.setProperty('top', '-9999px', 'important');
                        el.style.setProperty('pointer-events', 'none', 'important');
                    });
                });

                // Ensure the body has the portal-page-active class for CSS targeting
                document.body.classList.add('portal-page-active');
            });
        </script>
        <?php
    }
});
