<?php
/**
 * Consolidated Portal Pages Management
 * Separates "public pages" from "portal app pages"
 * 
 * PUBLIC PAGES (editable in WordPress):
 * - /resources/ → Normal WordPress page, Elementor-editable
 * - /about-us/, /partners/, etc. → Normal WordPress pages
 * 
 * PORTAL APP PAGES (programmatic, React-based):
 * - /portal/ → React app (single page application)
 * - /dashboard/, /portal-profile/, /portal-resources/ → React routes within /portal/
 */

if (!defined('ABSPATH')) {
    exit;
}

if (defined('PORTAL_PAGES_CONSOLIDATED_LOADED')) {
    return;
}
define('PORTAL_PAGES_CONSOLIDATED_LOADED', true);

/**
 * STRATEGY:
 * 1. Only ONE page needs to exist: "Portal" (/portal/)
 * 2. All other portal routes are handled by React client-side routing
 * 3. /resources/ is a NORMAL WordPress page, separate from /portal-resources/
 * 4. This eliminates the Elementor conflict
 */

/**
 * Step 1: Fix the Public "Resources" page
 * This is the main site resources page, NOT part of the portal
 */
function create_or_fix_public_resources_page() {
    $resource_page = get_page_by_path('resources');
    
    if ($resource_page) {
        // Page exists but might have wrong template
        $page_template = get_page_template_slug($resource_page->ID);
        
        if (!empty($page_template) && $page_template !== 'default') {
            // Remove custom template to use default (Elementor can edit it)
            update_post_meta($resource_page->ID, '_wp_page_template', 'default');
            error_log("[Portal Fix] Removed custom template from Resources page ID " . $resource_page->ID);
        }
    }
}

// Run on admin pages
if (is_admin()) {
    add_action('admin_init', 'create_or_fix_public_resources_page');
}

/**
 * Step 2: Create Portal App Pages (if they don't exist)
 * These pages just act as entry points to the React app
 */
function ensure_portal_app_pages_exist() {
    $portal_pages = [
        [
            'post_title'   => 'Portal',
            'post_name'    => 'portal',
            'post_type'    => 'page',
            'post_status'  => 'publish',
            'post_content' => '<div id="portal-root"></div>' // React will mount here
        ]
    ];

    foreach ($portal_pages as $page_data) {
        $existing_page = get_page_by_path($page_data['post_name']);
        
        if (!$existing_page) {
            wp_insert_post($page_data);
            error_log("[Portal Fix] Created portal page: " . $page_data['post_name']);
        }
    }
}

if (is_admin()) {
    add_action('admin_init', 'ensure_portal_app_pages_exist', 11); // After create_or_fix_public_resources_page
}

/**
 * Step 3: Detect Portal App vs Public Pages
 * Portal app: /portal/* → route via React
 * Public: /resources/, /about-us/, etc. → route via WordPress templates
 */
function detect_portal_app_page() {
    $current_url = $_SERVER['REQUEST_URI'];
    
    // Portal app pages - all routes starting with /portal/
    $portal_routes = [
        '/portal/',
        '/dashboard/',
        '/portal-profile/',
        '/portal-resources/',
        '/portal-referrals/',
        '/portal-login/',
        '/register/'
    ];

    foreach ($portal_routes as $route) {
        if (strpos($current_url, $route) === 0) {
            return 'portal_app'; // Use React app routing
        }
    }

    return 'wordpress_page'; // Use normal WordPress template
}

/**
 * Step 4: Template routing - use correct template file
 */
add_filter('template_include', function($template) {
    $page_type = detect_portal_app_page();
    
    if ($page_type === 'portal_app') {
        // Use the main portal template
        $portal_template = get_template_directory() . '/page-portal-final.php';
        
        if (file_exists($portal_template)) {
            return $portal_template;
        }
    }
    
    return $template;
}, 10, 1);

/**
 * Step 5: Hide portal app pages from WordPress admin navigation
 * Users shouldn't edit /dashboard/ directly - it's auto-routed by React
 */
function hide_internal_portal_pages_from_admin() {
    // These are managed programmatically, don't show edit screens
    $internal_portal_slugs = ['dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'portal-login'];
    
    // If on edit page of an internal portal page, show warning
    if (is_admin() && isset($_GET['page'])) {
        $current_page = get_post();
        if ($current_page && in_array($current_page->post_name, $internal_portal_slugs)) {
            add_action('admin_notices', function() {
                ?>
                <div class="notice notice-info">
                    <p><strong>Portal App Page:</strong> This page is managed programmatically by React. Edits here won't be visible. Modify content in /portal/ or update the React component.</p>
                </div>
                <?php
            });
        }
    }
}

add_action('admin_init', 'hide_internal_portal_pages_from_admin');

/**
 * Step 6: Debug helper - show page detection
 */
function portal_page_detection_debug() {
    if (current_user_can('manage_options') && isset($_GET['debug_portal'])) {
        $page_type = detect_portal_app_page();
        error_log("[Portal Debug] Current URL: " . $_SERVER['REQUEST_URI']);
        error_log("[Portal Debug] Page Type: " . $page_type);
        error_log("[Portal Debug] Is Portal: " . (is_page('portal') ? 'true' : 'false'));
    }
}

add_action('template_redirect', 'portal_page_detection_debug');
