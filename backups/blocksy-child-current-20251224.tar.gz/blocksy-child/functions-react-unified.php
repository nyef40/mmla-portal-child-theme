<?php
/**
 * Unified React App Integration
 * Loads single React bundle for entire website
 */

// Enqueue unified React app
add_action('wp_enqueue_scripts', function() {
    // Only load on React app page
    if (is_page_template('page-react-app.php') || is_page('portal') || 
        is_page('dashboard') || is_page('our-services') || is_page('about-us') || 
        is_page('ivig-news')) {
        
        $react_dir = get_stylesheet_directory() . '/react-app/dist/';
        $react_url = get_stylesheet_directory_uri() . '/react-app/dist/';
        
        // Enqueue React app bundle
        if (file_exists($react_dir . 'app.js')) {
            wp_enqueue_script(
                'mmla-react-app',
                $react_url . 'app.js',
                array(),
                filemtime($react_dir . 'app.js'),
                true
            );
        }
        
        // Enqueue React app styles
        if (file_exists($react_dir . 'app.css')) {
            wp_enqueue_style(
                'mmla-react-app-styles',
                $react_url . 'app.css',
                array(),
                filemtime($react_dir . 'app.css')
            );
        }
        
        // Hide WordPress theme header/footer
        remove_action('wp_head', 'wp_print_styles', 8);
        remove_action('wp_head', 'wp_print_head_scripts', 9);
    }
}, 100);

// Add rewrite rules for React routing
add_action('init', function() {
    // Main site pages
    add_rewrite_rule('^our-services/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^about-us/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^ivig-news/?$', 'index.php?pagename=react-app', 'top');
    
    // Portal pages
    add_rewrite_rule('^portal/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^portal-login/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^register/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^dashboard/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^portal-profile/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^portal-resources/?$', 'index.php?pagename=react-app', 'top');
    add_rewrite_rule('^portal-referrals/?$', 'index.php?pagename=react-app', 'top');
});

// Force template for React routes
add_filter('template_include', function($template) {
    $react_pages = ['our-services', 'about-us', 'ivig-news', 'portal', 'portal-login', 
                    'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals'];
    
    $current_path = trim(parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH), '/');
    
    if (in_array($current_path, $react_pages)) {
        $react_template = get_stylesheet_directory() . '/page-react-app.php';
        if (file_exists($react_template)) {
            return $react_template;
        }
    }
    
    return $template;
}, 99);
