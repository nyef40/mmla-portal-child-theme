<?php
/**
 * Blocksy Child Theme Functions
 * This file contains all the custom functionality for the portal system.
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

date_default_timezone_set('America/Los_Angeles');

// Force all WordPress system emails to use Google Workspace
function force_wp_mail_from($original_email_address) {
    return 'nick.yefimov@mobilemedicalla.com';
}
add_filter('wp_mail_from', 'force_wp_mail_from');

function force_wp_mail_from_name($original_email_from) {
    return 'Mobile Medical LA';
}
add_filter('wp_mail_from_name', 'force_wp_mail_from_name');

// Redirect system emails from invalid addresses
function redirect_system_emails($email) {
    $invalid_emails = array(
        'c9gyjyiudq9m@p3plzcpnl503868.prod.phx3.secureserver.net',
        // add any other invalid emails here
    );
    
    if (in_array($email, $invalid_emails)) {
        return 'nyef40mmla@gmail.com';
    }
    
    return $email;
}
add_filter('wp_mail', 'redirect_system_emails');

// Add this to functions.php for consistent debugging
function portal_debug($message, $data = null, $file = 'portal-debug.log') {
    $timestamp = date('Y-m-d H:i:s');
    $log_entry = "[$timestamp] $message";
    
    if ($data !== null) {
        $log_entry .= " | Data: " . (is_array($data) ? json_encode($data) : $data);
    }
    
    $log_entry .= " | User: " . (is_user_logged_in() ? get_current_user_id() : '0');
    $log_entry .= " | Page: " . ($_SERVER['REQUEST_URI'] ?? 'unknown');
    
    error_log($log_entry);
}

add_action('wp_ajax_nopriv_portal_register', 'handle_portal_register');
// for logged-in users for debugging 
add_action('wp_ajax_portal_register', 'handle_portal_register');
add_action('init', function() {
    if (isset($_REQUEST['action']) && $_REQUEST['action'] === 'portal_register') {
        error_log('AJAX request received for action=portal_register, POST data: ' . print_r($_POST, true));
    }
});

add_filter('wp_mail_from', function($email) {
    error_log('wp_mail_from filter applied, returning: ' . (defined('WPMS_FROM') ? WPMS_FROM : 'no-reply@mmla.local'));
    return defined('WPMS_FROM') ? WPMS_FROM : 'no-reply@mmla.local';
});
add_filter('wp_mail_from_name', function($name) {
    error_log('wp_mail_from_name filter applied, returning: ' . (defined('WPMS_FROM_NAME') ? WPMS_FROM_NAME : 'Mobile Medical LA'));
    return defined('WPMS_FROM_NAME') ? WPMS_FROM_NAME : 'Mobile Medical LA';
});

add_filter('elementor_pro/admin/validate_nonce', '__return_true', 9999);

add_action('wp_enqueue_scripts', function() {
    wp_enqueue_script('elementor-fix', '', array('elementor-frontend'), false, true);
    wp_add_inline_script('elementor-fix', '
        if (typeof elementorFrontend === "object") {
            elementorFrontend.hooks = elementorFrontend.hooks || {};
            elementorFrontend.hooks.addAction = elementorFrontend.hooks.addAction || function() {};
        }
    ');
});

/**
add_filter('nonce_user_logged_out', function($uid, $action) {
    return 0; // Force nonce to work for logged-out users
}, 9999);
*/

add_filter('wp_verify_nonce', function($nonce, $action) {
    if (in_array($action, ['elementor_ajax', 'heartbeat-nonce', 'wp_rest', 'edit-entry'])) {
        return true; // Bypass nonce verification for debugging
    }
    return $nonce;
}, 9999, 2);

add_action('after_setup_theme', function() {
    if (!current_user_can('manage_options')) {
        show_admin_bar(false);
    }
});

add_action('admin_enqueue_scripts', function() {
    wp_enqueue_script('wp-auth-check-fix', '', array('wp-auth-check'), false, true);
    wp_add_inline_script('wp-auth-check-fix', '
        jQuery(document).ready(function($) {
            if (typeof wp === "object" && typeof wp.authcheck === "object") {
                wp.authcheck.init = function() {
                    if ($("#wp-auth-check-wrap").length) {
                        $("#wp-auth-check-wrap").addClass("hidden");
                    }
                };
            }
        });
    ');
});

add_action('wp_logout', function($user_id) {
    error_log("wp_logout triggered for user_id: $user_id, REQUEST_URI: " . $_SERVER['REQUEST_URI']);
    error_log("Cookies before logout: " . print_r($_COOKIE, true));
}, 10, 1);

add_action('template_redirect', function() {
    if (is_page('portal')) {
        error_log("Template redirect for /portal/, is_user_logged_in: " . (is_user_logged_in() ? 'true' : 'false'));
        error_log("Template redirect Cookies: " . print_r($_COOKIE, true));
    }
}, 0);

// Include portal authentication functions
$auth_file = get_stylesheet_directory() . '/functions-portal-auth-enhanced.php';
if (file_exists($auth_file)) {
    require_once $auth_file;
}

add_action('wp_footer', function() {
    echo '<script>
        if (typeof window.elementorCommon === "object" && !window.elementorCommon.helpers) {
            window.elementorCommon.helpers = { softDeprecated: function() {} };
        }
    </script>';
});

/**
 * Enqueue child theme styles
 */
function blocksy_child_enqueue_styles() {
    
    $current_page = get_post_field('post_name', get_post());
    $request_uri = $_SERVER['REQUEST_URI'];
    error_log("Current page: $current_page, REQUEST_URI: $request_uri");
    
    // Enqueue parent theme styles
    wp_enqueue_style('blocksy-parent-style', get_template_directory_uri() . '/style.css');
    
    // Enqueue child theme styles
    wp_enqueue_style('blocksy-child-style', get_stylesheet_directory_uri() . '/style.css', ['blocksy-parent-style']);
    
    // Enqueue portal CSS on portal pages only
    $portal_pages = ['portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact'];
    if (is_page($portal_pages) || strpos($_SERVER['REQUEST_URI'], '/portal') !== false || strpos($_SERVER['REQUEST_URI'], '/dashboard') !== false || strpos($_SERVER['REQUEST_URI'], '/register') !== false || strpos($_SERVER['REQUEST_URI'], '/contact') !== false) {
        
        error_log("Portal page detected: $current_page, enqueuing styles/scripts");
        
        wp_enqueue_style('portal-css', get_stylesheet_directory_uri() . '/portal/dist/portal.css', ['blocksy-child-style']);
        
        // Enqueue portal JavaScript
        wp_enqueue_script('portal-js', get_stylesheet_directory_uri() . '/portal/dist/portal.js', ['jquery'], '1.0', true);
        
        // Localize portal data
        wp_localize_script('portal-js', 'portalData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('portal_nonce'),
            'isLoggedIn' => is_user_logged_in(),
            'currentUser' => is_user_logged_in() ? wp_get_current_user() : null,
            'dashboardUrl' => home_url('/dashboard/'),
            'loginUrl' => home_url('/portal-login/'),
            'registerUrl' => home_url('/register/'),
            'logoutUrl' => wp_logout_url(home_url('/portal/')),
            'mainSiteUrl' => home_url('/')
        ]);
    }
}
add_action('wp_enqueue_scripts', 'blocksy_child_enqueue_styles');

/**
 * Add portal-specific body classes
 */
function add_portal_body_classes($classes) {
    $portal_pages = ['portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact'];
    
    if (is_page($portal_pages)) {
        $classes[] = 'portal-page-active';
        $classes[] = 'portal-page-' . get_post_field('post_name', get_post());
    }
    
    return $classes;
}
add_filter('body_class', 'add_portal_body_classes');

/**
 * Add portal header only on portal pages
 */
function add_portal_header() {
    $portal_pages = ['portal', 'portal-login', 'register', 'dashboard', 'portal-profile', 'portal-resources', 'portal-referrals', 'contact'];
    
    if (is_page($portal_pages)) {
        // Hide main site navigation
        add_action('wp_head', function() {
            echo '<style>
                body.portal-page-active .ct-header,
                body.portal-page-active .site-header,
                body.portal-page-active #masthead,
                body.portal-page-active .main-navigation,
                body.portal-page-active .ct-footer {
                    display: none !important;
                }
            </style>';
        }, 999);
        
        // Add portal header
        add_action('wp_body_open', function() {
            static $header_added = false;
            if ($header_added) return;
            $header_added = true;
            
            $current_uri = $_SERVER['REQUEST_URI'];
            ?>
            <div class="portal-header" style="background: linear-gradient(135deg, #0A3D62 0%, #1e5f8b 100%); padding: 15px 0; box-shadow: 0 4px 20px rgba(10, 61, 98, 0.3); position: sticky; top: 0; z-index: 9999;">
                <div class="portal-header-content" style="max-width: 1200px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; padding: 0 20px;">
                    <a href="/portal/" class="portal-logo" style="color: white; font-size: 20px; font-weight: 700; text-decoration: none; display: flex; align-items: center; gap: 8px;">
                        🏥 Mobile Medical LA Portal
                    </a>
                    
                    <div class="portal-nav-menu" style="display: flex; gap: 15px; align-items: center;">
                        <a href="/portal/" class="portal-nav-item <?php echo (strpos($current_uri, '/portal/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/portal/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Home</a>
                        
                        <?php if (is_user_logged_in()): ?>
                        <a href="/dashboard/" class="portal-nav-item <?php echo (strpos($current_uri, '/dashboard/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/dashboard/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Dashboard</a>
                        <a href="/portal-profile/" class="portal-nav-item <?php echo (strpos($current_uri, '/portal-profile/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/portal-profile/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Profile</a>
                        <a href="/portal-resources/" class="portal-nav-item <?php echo (strpos($current_uri, '/portal-resources/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/portal-resources/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Resources</a>
                        <a href="/portal-referrals/" class="portal-nav-item <?php echo (strpos($current_uri, '/portal-referrals/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/portal-referrals/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Referrals</a>
                        <a href="/contact/" class="portal-nav-item <?php echo (strpos($current_uri, '/contact/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/contact/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Contact</a>
                        <a href="<?php echo wp_logout_url(home_url('/portal/')); ?>" class="portal-nav-item logout-btn" style="background: rgba(220, 53, 69, 0.8); color: white; text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px;">Logout</a>
                        <?php else: ?>
                        <a href="/portal-login/" class="portal-nav-item <?php echo (strpos($current_uri, '/portal-login/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/portal-login/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Login</a>
                        <a href="/register/" class="portal-nav-item <?php echo (strpos($current_uri, '/register/') !== false ? 'active' : ''); ?>" style="color: rgba(255, 255, 255, 0.8); text-decoration: none; padding: 8px 16px; border-radius: 20px; transition: all 0.3s ease; font-weight: 500; font-size: 14px; <?php echo (strpos($current_uri, '/register/') !== false ? 'background: rgba(255, 255, 255, 0.2); color: white;' : ''); ?>">Register</a>
                        <?php endif; ?>
                    </div>
                    
                    <a href="/" class="portal-back-btn" style="background: rgba(255, 255, 255, 0.2); color: white; padding: 10px 20px; border-radius: 20px; text-decoration: none; font-weight: 600; transition: all 0.3s ease; backdrop-filter: blur(10px); border: 1px solid rgba(255, 255, 255, 0.3); font-size: 14px;">← Main Site</a>
                </div>
            </div>
            <?php
        }, 1);
    }
}
add_action('template_redirect', 'add_portal_header');

/**
 * Register portal menu location
 */
function register_portal_menu() {
    register_nav_menus([
        'portal' => __('Portal Menu', 'blocksy-child'),
    ]);
}
add_action('init', 'register_portal_menu');

/**
 * Create encryption key function if it doesn't exist
 */
if (!function_exists('get_encryption_key')) {
    function get_encryption_key() {
        $key = get_option('portal_encryption_key');
        if (!$key) {
            $key = wp_generate_password(32, false);
            update_option('portal_encryption_key', $key);
        }
        return $key;
    }
}

/**
 * Get encryption key for patient data
 */
function get_encryption_key() {
    if (defined('MMLA_ENCRYPTION_KEY')) {
        return MMLA_ENCRYPTION_KEY;
    }
    
    if (defined('SECURE_AUTH_KEY')) {
        return substr(SECURE_AUTH_KEY, 0, 16);
    }
    
    return 'mmla_2025';
}


add_action('wp_ajax_nopriv_portal_register', 'handle_portal_register');
add_action('wp_ajax_portal_register', 'handle_portal_register');
function handle_portal_register() {
    global $wpdb;
    error_log('handle_portal_register called, POST data: ' . print_r($_POST, true));
    if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'portal_register_nonce')) {
        error_log('Nonce verification failed');
        wp_send_json_error(['message' => 'Invalid nonce']);
        return;
    }
    $first_name = sanitize_text_field($_POST['first_name']);
    $last_name = sanitize_text_field($_POST['last_name']);
    $email = sanitize_email($_POST['email']);
    $phone = sanitize_text_field($_POST['phone']);
    $username = sanitize_user($_POST['username']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    $role = sanitize_text_field($_POST['role']);
    $specialty = sanitize_text_field($_POST['specialty']);
    $license_number = sanitize_text_field($_POST['license_number']);
    $practice_name = sanitize_text_field($_POST['practice_name']);
    $address = sanitize_text_field($_POST['address']);
    $city = sanitize_text_field($_POST['city']);
    $state = sanitize_text_field($_POST['state']);
    $zip = sanitize_text_field($_POST['zip']);
    if ($password !== $confirm_password) {
        error_log('Registration failed: Passwords do not match');
        wp_send_json_error(['message' => 'Passwords do not match']);
        return;
    }
    $user_id = wp_create_user($username, $password, $email);
    if (is_wp_error($user_id)) {
        error_log('Registration failed: wp_create_user error - ' . $user_id->get_error_message());
        wp_send_json_error(['message' => 'Registration failed: ' . $user_id->get_error_message()]);
        return;
    }
    wp_update_user(['ID' => $user_id, 'first_name' => $first_name, 'last_name' => $last_name, 'role' => 'subscriber']);
    $token = bin2hex(random_bytes(32));
    $result = $wpdb->insert(
        $wpdb->prefix . 'portal_users',
        [
            'wp_user_id' => $user_id,
            'username' => $username,
            'email' => $email,
            'first_name' => $first_name,
            'last_name' => $last_name,
            'phone' => $phone,
            'practice' => $practice_name,
            'specialty' => $specialty,
            'license_number' => $license_number,
            'role' => $role,
            'address' => $address,
            'city' => $city,
            'state' => $state,
            'zip' => $zip,
            'email_verified' => 0,
            'validation_token' => $token,
            'created_at' => current_time('mysql')
        ],
        ['%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s']
    );
    if ($result === false) {
        error_log('Registration failed: Database insert error - ' . $wpdb->last_error);
        $wpdb->delete($wpdb->prefix . 'portal_users', ['wp_user_id' => $user_id], ['%d']);
        wp_delete_user($user_id);
        wp_send_json_error(['message' => 'Registration failed: Database error']);
        return;
    }
    $validation_link = add_query_arg(['action' => 'validate_email', 'token' => $token, 'user_id' => $user_id], home_url('/'));
    $subject = 'Verify Your Mobile Medical LA Portal Account';
    $message = "
    <html>
    <body>
        <h2>Welcome to Mobile Medical LA Portal</h2>
        <p>Please verify your email by clicking the link below:</p>
        <p><a href='$validation_link'>Verify Email</a></p>
    </body>
    </html>";
    $headers = [
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . (defined('WPMS_FROM_NAME') ? WPMS_FROM_NAME : 'Mobile Medical LA') . ' <' . (defined('WPMS_FROM') ? WPMS_FROM : 'no-reply@mmla.local') . '>'
    ];
    add_action('wp_mail_failed', function($wp_error) {
        error_log('wp_mail failed: ' . print_r($wp_error, true));
    });
    error_log('Sending wp_mail with From: ' . (defined('WPMS_FROM_NAME') ? WPMS_FROM_NAME : 'Mobile Medical LA') . ' <' . (defined('WPMS_FROM') ? WPMS_FROM : 'no-reply@mmla.local') . '>');
    if (wp_mail($email, $subject, $message, $headers)) {
        error_log('Registration successful: Email sent to ' . $email);
        wp_send_json_success(['message' => 'Registration successful! Please check your email to verify your account.']);
    } else {
        error_log('Registration failed: wp_mail failed for ' . $email);
        $wpdb->delete($wpdb->prefix . 'portal_users', ['wp_user_id' => $user_id], ['%d']);
        wp_delete_user($user_id);
        wp_send_json_error(['message' => 'Failed to send verification email. Please try again.']);
    }
}

add_action('init', function() {
    if (isset($_GET['action']) && $_GET['action'] === 'validate_email' && isset($_GET['token']) && isset($_GET['user_id'])) {
        global $wpdb;
        $user_id = intval($_GET['user_id']);
        $token = sanitize_text_field($_GET['token']);
        $result = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$wpdb->prefix}portal_users WHERE wp_user_id = %d AND validation_token = %s AND email_verified = 0",
                $user_id,
                $token
            )
        );
        if ($result) {
            $wpdb->update(
                $wpdb->prefix . 'portal_users',
                ['email_verified' => 1, 'updated_at' => current_time('mysql')],
                ['wp_user_id' => $user_id, 'validation_token' => $token],
                ['%d', '%s'],
                ['%d', '%s']
            );
            wp_redirect(home_url('/portal-login/?validated=1'));
            exit;
        } else {
            wp_redirect(home_url('/register/?error=invalid_token'));
            exit;
        }
    }
});

/**
 * WPForms referral handling
 */
function handle_referral_submission($fields, $entry, $form_data, $entry_id = null) {
    if ($form_data['id'] != 1479) {
        return $fields;
    }
    try {
        global $wpdb;
        $provider_name = isset($fields[2]['value']) ? sanitize_text_field($fields[2]['value']) : '';
        $provider_practice = isset($fields[14]['value']) ? sanitize_text_field($fields[14]['value']) : '';
        $provider_email = '';
        if (isset($fields[15]['value'])) {
            $provider_email = is_array($fields[15]['value']) ? sanitize_email($fields[15]['value']['primary']) : sanitize_email($fields[15]['value']);
        }
        $provider_phone = isset($fields[16]['value']) ? sanitize_text_field($fields[16]['value']) : '';
        $patient_name = isset($fields[18]['value']) ? sanitize_text_field($fields[18]['value']) : '';
        $patient_email = isset($fields[19]['value']) ? sanitize_email($fields[19]['value']) : '';
        $patient_phone = isset($fields[20]['value']) ? sanitize_text_field($fields[20]['value']) : '';
        $insurance = isset($fields[21]['value']) ? sanitize_text_field($fields[21]['value']) : '';
        $reason = isset($fields[23]['value']) ? sanitize_text_field($fields[23]['value']) : '';
        $notes = isset($fields[24]['value']) ? sanitize_textarea_field($fields[24]['value']) : '';
        $validation_token = wp_generate_uuid4();
        $encryption_key = get_encryption_key();
        $table_name = $wpdb->prefix . 'referral_submissions';
        $result = $wpdb->query($wpdb->prepare('INSERT INTO ' . $table_name . '
              (provider_name, provider_practice, provider_email, provider_phone,
               patient_name, patient_email, patient_phone, insurance,
               reason, notes, validation_token, is_validated, created_at)
             VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %d, %s)',
            $provider_name, $provider_practice, $provider_email, $provider_phone,
            $patient_name, $patient_email, $patient_phone, $insurance,
            $reason, $notes, $validation_token, 0, current_time('mysql')
        ));
        if ($result !== false) {
            $submission_id = $wpdb->insert_id;
            $wpdb->query($wpdb->prepare("UPDATE {$table_name} SET
                  patient_name = AES_ENCRYPT(%s, %s),
                 patient_email = AES_ENCRYPT(%s, %s),
                 insurance = AES_ENCRYPT(%s, %s)
 WHERE submission_id = %d",
                $patient_name, $encryption_key,
                $patient_email, $encryption_key,
                $insurance, $encryption_key,
                $submission_id
            ));
            $validation_url = add_query_arg(
                ['action' => 'validate_email', 'token' => $validation_token, 'submission_id' => $submission_id],
                home_url()
            );
            $actual_entry_id = $entry_id ?: (isset($entry['id']) ? $entry['id'] : null);
            if ($actual_entry_id) {
                update_option('wpforms_validation_url_' . $actual_entry_id, $validation_url, true);
            }
        }
    } catch (Exception $e) {
        error_log('ERROR in referral processing: ' . $e->getMessage(), 3, WP_CONTENT_DIR . '/debug.log');
    }
    return $fields;
}
add_action('wpforms_process_complete', 'handle_referral_submission', 10, 4);

function handle_email_validation() {
    if (isset($_GET['action']) && $_GET['action'] === 'validate_email' && isset($_GET['token']) && isset($_GET['submission_id'])) {
        global $wpdb;
        $token = sanitize_text_field($_GET['token']);
        $submission_id = intval($_GET['submission_id']);
        $table_name = $wpdb->prefix . 'referral_submissions';
        $submission = $wpdb->get_row($wpdb->prepare("SELECT * FROM {$table_name} WHERE submission_id = %d AND validation_token = %s",
            $submission_id, $token
        ));
        if ($submission) {
            $wpdb->update($table_name,
                ['is_validated' => 1],
                ['submission_id' => $submission_id],
                ['%d'],
                ['%d']
            );
            wp_redirect(add_query_arg('validated', '1', home_url()));
            exit;
        } else {
            wp_die('Invalid or expired validation token.');
        }
    }
}
add_action('init', 'handle_email_validation');

/**
 * Get HTML email template with styled validation button
 */
function get_provider_email_template($provider_name, $validation_url) {
    return '
    <div style="font-family: Arial, sans-serif; line-height: 1.6; color: #333; max-width: 600px; margin: 0 auto; padding: 20px; background: white; border-radius: 8px;">
        <h2 style="color: #0066cc;">Email Validation Required</h2>
        <p>Dear ' . esc_html($provider_name) . ',</p>
        <p>Thank you for referring a patient to Mobile Medical LA. Please validate your email by clicking below:</p>
        <div style="text-align: center; margin: 20px 0;">
            <a href="' . esc_url($validation_url) . '" style="background: #0066cc; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; display: inline-block;">Validate Email</a>
        </div>
        <p>Or copy this link: <a href="' . esc_url($validation_url) . '">' . esc_url($validation_url) . '</a></p>
        <p>Best regards,<br>Mobile Medical LA Team</p>
    </div>';
}

/**
 * Helper function to get validation URL
 */
function get_validation_url($entry_id) {
    global $wpdb;
    
    // Try transient first
    $transient_key = 'wpforms_validation_url_' . $entry_id;
    $validation_url = get_transient($transient_key);
    error_log("Transient lookup for entry_id $entry_id: " . ($validation_url ? "Found" : "Not found"), 3, WP_CONTENT_DIR . '/debug.log');
    
    if ($validation_url) {
        return $validation_url;
    }
    
    // Try option next
    $validation_url = get_option('wpforms_validation_url_' . $entry_id);
    error_log("Option lookup for entry_id $entry_id: " . ($validation_url ? "Found" : "Not found"), 3, WP_CONTENT_DIR . '/debug.log');
    
    if ($validation_url) {
        return $validation_url;
    }
    
    // Try direct database lookup
    try {
        // Get provider email from entry
        $provider_email = $wpdb->get_var($wpdb->prepare(
            "SELECT value FROM {$wpdb->prefix}wpforms_entry_fields 
             WHERE entry_id = %d AND field_id = 15",
            $entry_id
        ));
        
        if ($provider_email) {
            error_log("Found provider email for entry $entry_id: $provider_email", 3, WP_CONTENT_DIR . '/debug.log');
            
            // Use direct query with BINARY to force case-sensitive comparison
            $submission = $wpdb->get_row($wpdb->prepare(
                "SELECT submission_id, validation_token 
                 FROM {$wpdb->prefix}referral_submissions 
                 WHERE provider_email = %s 
                 ORDER BY submission_id DESC LIMIT 1",
                $provider_email
            ));
            
            if ($submission) {
                $validation_url = add_query_arg(
                    array(
                        'action' => 'validate_email',
                        'token' => $submission->validation_token,
                        'submission_id' => $submission->submission_id
                    ),
                    home_url()
                );
                
                // Save for future use
                set_transient($transient_key, $validation_url, 14 * DAY_IN_SECONDS);
                update_option('wpforms_validation_url_' . $entry_id, $validation_url, false);
                
                // error_log("Created validation URL from submission: $validation_url", 3, WP_CONTENT_DIR . '/debug.log');
                return $validation_url;
            }
        }
    } catch (Exception $e) {
        error_log("Error in get_validation_url: " . $e->getMessage(), 3, WP_CONTENT_DIR . '/debug.log');
    }
    
    // Last resort - get the most recent submission
    try {
        $submission = $wpdb->get_row(
            "SELECT submission_id, validation_token 
             FROM {$wpdb->prefix}referral_submissions 
             ORDER BY submission_id DESC LIMIT 1"
        );
        
        if ($submission) {
            $validation_url = add_query_arg(
                array(
                    'action' => 'validate_email',
                    'token' => $submission->validation_token,
                    'submission_id' => $submission->submission_id
                ),
                home_url()
            );
            
            // error_log("Last resort validation URL from most recent submission: $validation_url", 3, WP_CONTENT_DIR . '/debug.log');
            return $validation_url;
        }
    } catch (Exception $e) {
        error_log("Error in get_validation_url last resort: " . $e->getMessage(), 3, WP_CONTENT_DIR . '/debug.log');
    }
    
    return false;
}
/**
 * Force WPForms to send HTML emails
 */
function force_wpforms_html_email($args) {
    $args['headers'] = is_array($args['headers']) ? $args['headers'] : [];
    $args['headers'][] = 'Content-Type: text/html; charset=UTF-8';
    $args['headers'][] = 'MIME-Version: 1.0';
    error_log("WPForms email headers set: " . print_r($args['headers'], true), 3, WP_CONTENT_DIR . '/debug.log');
    return $args;
}
add_filter('wpforms_email_send_args', 'force_wpforms_html_email', 999, 1);
/**
 * Send fallback admin notification
 */
function send_fallback_admin_notification($fields, $entry, $form_data, $entry_id) {
    if ($form_data['id'] != 1479) {
        return;
    }
    
    // Get form field values
    $provider_name = isset($fields[2]['value']) ? sanitize_text_field($fields[2]['value']) : '';
    $provider_practice = isset($fields[14]['value']) ? sanitize_text_field($fields[14]['value']) : '';
    $provider_email = isset($fields[15]['value']) ? sanitize_email($fields[15]['value']) : '';
    $provider_phone = isset($fields[16]['value']) ? sanitize_text_field($fields[16]['value']) : '';
    $patient_name = isset($fields[18]['value']) ? sanitize_text_field($fields[18]['value']) : '';
    $reason = isset($fields[23]['value']) ? sanitize_text_field($fields[23]['value']) : '';
    
    // Store the notification in the database instead of sending email
    global $wpdb;
    $table_name = $wpdb->prefix . 'admin_notifications';
    
    // Create the table if it doesn't exist
    $wpdb->query("
        CREATE TABLE IF NOT EXISTS {$table_name} (
            id INT AUTO_INCREMENT PRIMARY KEY,
            provider_name VARCHAR(255),
            provider_email VARCHAR(255),
            patient_name VARCHAR(255),
            reason VARCHAR(255),
            submission_id INT,
            created_at DATETIME,
            is_read TINYINT DEFAULT 0
        )
    ");
    
    // Get the most recent submission ID
    $submission_id = $wpdb->get_var("SELECT MAX(submission_id) FROM {$wpdb->prefix}referral_submissions");
    
    // Insert the notification
    $wpdb->insert(
        $table_name,
        array(
            'provider_name' => $provider_name,
            'provider_email' => $provider_email,
            'patient_name' => $patient_name,
            'reason' => $reason,
            'submission_id' => $submission_id,
            'created_at' => current_time('mysql'),
            'is_read' => 0
        )
    );
    
    error_log("Admin notification stored in database for submission ID: $submission_id", 3, WP_CONTENT_DIR . '/debug.log');
    
    // Try sending via alternative method
    try {
        // HTML version
        $html_message = "<!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial, sans-serif; line-height: 1.6; }
                .container { max-width: 600px; margin: 0 auto; padding: 20px; }
                h1 { color: #0073aa; }
                .details { background: #f9f9f9; padding: 15px; border-left: 4px solid #0073aa; }
            </style>
        </head>
        <body>
            <div class='container'>
                <h1>New Patient Referral</h1>
                <div class='details'>
                    <p><strong>Provider:</strong> {$provider_name}</p>
                    <p><strong>Practice:</strong> {$provider_practice}</p>
                    <p><strong>Email:</strong> {$provider_email}</p>
                    <p><strong>Phone:</strong> {$provider_phone}</p>
                    <p><strong>Patient:</strong> {$patient_name}</p>
                    <p><strong>Reason:</strong> {$reason}</p>
                </div>
                <p>Please log in to the admin dashboard to view full details.</p>
            </div>
        </body>
        </html>";
        
        // Try using PHP's mail function directly as a last resort
        $subject = 'New Patient Referral';
        $headers = [
            'Content-Type: text/html; charset=UTF-8',
            'From: Mobile Medical LA <nyef40@gmail.com>',
        ];
        
        // Only use this in development - not recommended for production
        if (function_exists('mail')) {
            $mail_result = mail('nick.yefimov@mobilemedicalla.com', $subject, $html_message, implode("\r\n", $headers));
            error_log("PHP mail() function result: " . ($mail_result ? 'Success' : 'Failed'), 3, WP_CONTENT_DIR . '/debug.log');
        }
    } catch (Exception $e) {
        error_log("Error sending alternative admin notification: " . $e->getMessage(), 3, WP_CONTENT_DIR . '/debug.log');
    }
}

/**
 * Handle referral validation
 */
function handle_referral_validation() {
    date_default_timezone_set('America/Los_Angeles');

     if (isset($_GET['action']) && $_GET['action'] === 'validate_email' && 
        isset($_GET['token']) && isset($_GET['submission_id'])) {
        global $wpdb;
        $token = sanitize_text_field($_GET['token']);
        $submission_id = absint($_GET['submission_id']);
        // error_log("Validation attempt: Token=$token, Submission ID=$submission_id", 3, WP_CONTENT_DIR . '/debug.log');

        $table_name = $wpdb->prefix . 'referral_submissions';
        $submission = $wpdb->get_row($wpdb->prepare(
            "SELECT submission_id FROM {$table_name} 
             WHERE validation_token = %s AND submission_id = %d AND is_validated = 0",
            $token, $submission_id
        ));

        if ($submission) {
            $result = $wpdb->update(
                $table_name,
                array('is_validated' => 1),
                array('submission_id' => $submission->submission_id),
                array('%d'),
                array('%d')
            );
            if ($result === false) {
                error_log("ERROR: Failed to update is_validated for submission_id=$submission_id: " . $wpdb->last_error, 3, WP_CONTENT_DIR . '/debug.log');
                wp_die('Validation failed due to a database error.', 'Validation Error', array('response' => 500));
            }
            error_log("Validation successful: Updated is_validated for submission_id=$submission_id", 3, WP_CONTENT_DIR . '/debug.log');
            wp_die('Thank you! Your email has been successfully validated.', 'Email Validated', array('response' => 200));
        } else {
            error_log("ERROR: Invalid token or submission already validated for submission_id=$submission_id", 3, WP_CONTENT_DIR . '/debug.log');
            wp_die('Invalid validation link or already validated.', 'Validation Failed', array('response' => 400));
        }
    }
}
add_action('init', 'handle_referral_validation');

add_action('wp_mail_failed', function($wp_error) {
    error_log("wp_mail failed: " . print_r($wp_error, true));
});
add_filter('wp_mail', function($args) {
    error_log("wp_mail called: Subject: {$args['subject']}, To: {$args['to']}");
    return $args;
});

/**
 * Enhanced last chance email modification to reinforce HTML headers

 */
function last_chance_email_modification($args) {
    global $wpdb;
    error_log("Last chance email modification", 3, WP_CONTENT_DIR . '/debug.log');

    // Ensure HTML headers
    $args['headers'] = is_array($args['headers']) ? $args['headers'] : [];
    $args['headers'][] = 'Content-Type: text/html; charset=UTF-8';
    $args['headers'][] = 'MIME-Version: 1.0';
    error_log("wp_mail headers: " . print_r($args['headers'], true), 3, WP_CONTENT_DIR . '/debug.log');

    if (!isset($args['message']) || strpos($args['message'], '{validation_url}') === false) {
        error_log("No {validation_url} found in message", 3, WP_CONTENT_DIR . '/debug.log');
        return $args;
    }

    $to = isset($args['to']) ? $args['to'] : '';
    if (is_array($to)) {
        $to = reset($to);
    }
    error_log("Email recipient: $to", 3, WP_CONTENT_DIR . '/debug.log');

    $admin_emails = [
        'nick.yefimov@mobilemedicalla.com',
        'nyef40@gmail.com',
        get_option('admin_email')
    ];

    if (in_array($to, $admin_emails)) {
        error_log("Admin email detected - removing validation URL", 3, WP_CONTENT_DIR . '/debug.log');
        $args['message'] = str_replace('{validation_url}', '', $args['message']);
        return $args;
    }

    error_log("Provider email detected - adding validation URL", 3, WP_CONTENT_DIR . '/debug.log');

    if (!empty($to)) {
        $entry_id = $wpdb->get_var($wpdb->prepare(
            "SELECT entry_id FROM {$wpdb->prefix}wpforms_entry_fields 
             WHERE field_id = 15 AND value = %s 
             ORDER BY id DESC LIMIT 1",
            $to
        ));

        if ($entry_id) {
            error_log("Found entry ID $entry_id for email $to", 3, WP_CONTENT_DIR . '/debug.log');
            $validation_url = get_validation_url($entry_id);

            if ($validation_url) {
                $provider_name = $wpdb->get_var($wpdb->prepare(
                    "SELECT value FROM {$wpdb->prefix}wpforms_entry_fields 
                     WHERE entry_id = %d AND field_id = 2",
                    $entry_id
                ));
                $provider_name = $provider_name ?: 'Doctor';
                $html_template = get_provider_email_template($provider_name, $validation_url);
                $args['message'] = str_replace('{validation_url}', $html_template, $args['message']);
                error_log("Provider email: validation URL added: $validation_url", 3, WP_CONTENT_DIR . '/debug.log');
            } else {
                error_log("No validation URL generated for entry_id $entry_id", 3, WP_CONTENT_DIR . '/debug.log');
            }
        } else {
            error_log("No entry ID found for email $to", 3, WP_CONTENT_DIR . '/debug.log');
        }
    }
    return $args;
}

add_filter('wp_mail', 'last_chance_email_modification', 999);

// Track user login time
function update_portal_user_last_login($user_login, $user) {
    global $wpdb;
    // Correct UTC time for database storage
    $now_utc = gmdate('Y-m-d H:i:s');
    
    $portal_user_table = $wpdb->prefix . "portal_users";
    
    // Update last_login timestamp
    $wpdb->update(
        $portal_user_table,
        // array("last_login" => current_time("mysql")),
        array('last_login' => $now_utc),
        array("wp_user_id" => $user->ID),
        array("%s"),
        array("%d")
    );
    
    error_log("Updated last_login for user ID: " . $user->ID);
}

add_action("wp_login", "update_portal_user_last_login", 10, 2);

// Update last login after portal authentication
function update_portal_login_time($user_id) {
    global $wpdb;
    // Correct UTC time for database storage
    $now_utc = gmdate('Y-m-d H:i:s');
    
    $portal_user_table = $wpdb->prefix . "portal_users";
    
    $wpdb->update(
        $portal_user_table,
        // array("last_login" => current_time("mysql")),
        array('last_login' => $now_utc),
        array("wp_user_id" => $user_id),
        array("%s"),
        array("%d")
    );
    
    error_log("Portal login - Updated last_login for user ID: " . $user_id);
}

add_action( 'wp_enqueue_scripts', function() {
    // Only run on singular pages
    if (!is_singular('page')) {
        return;
    }
    
    // Get current page slug reliably
    $current_post_id = get_the_ID();
    $current_slug = get_post_field('post_name', $current_post_id);
    
    // Portal pages that should load portal.js
    $portal_pages = [
        'portal',
        'portal-login',
        'portal-profile',
        'portal-resources',
        'portal-referrals',
        'register',
        'dashboard',
        'contact'
    ];
    
    // Check if current page is a portal page
    if (!in_array($current_slug, $portal_pages)) {
        return;
    }
    
    // Log detection for debugging
    error_log("Portal page detected: {$current_slug}, enqueuing styles/scripts");
    
    $stylesheet_dir = get_stylesheet_directory();
    $stylesheet_uri = get_stylesheet_directory_uri();
    
    $portal_js_path = $stylesheet_dir . '/portal/dist/portal.js';
    $portal_css_path = $stylesheet_dir . '/portal/dist/portal.css';
    
    // Check if files exist
    if (!file_exists($portal_js_path) || !file_exists($portal_css_path)) {
        error_log("Portal assets missing! JS: " . file_exists($portal_js_path) . ", CSS: " . file_exists($portal_css_path));
        return;
    }
    
    // Enqueue portal JavaScript
    wp_enqueue_script(
        'portal-js',
        $stylesheet_uri . '/portal/dist/portal.js',
        [],
        filemtime($portal_js_path),
        true
    );

    // Enqueue portal CSS
    wp_enqueue_style(
        'portal-css',
        $stylesheet_uri . '/portal/dist/portal.css',
        [],
        filemtime($portal_css_path)
    );

    // Localize portal data
    wp_localize_script( 'portal-js', 'portalData', [
        'ajaxUrl' => admin_url( 'admin-ajax.php' ),
        'nonce' => wp_create_nonce( 'portal_nonce' ),
        'loginNonce' => wp_create_nonce( 'portal_login_nonce' ),
        'registerNonce' => wp_create_nonce( 'portal_register_nonce' ),
        'isLoggedIn' => is_user_logged_in(),
        'currentUser' => is_user_logged_in() ? wp_get_current_user() : null,
        'dashboardUrl' => home_url( '/dashboard/' ),
        'profileUrl' => home_url( '/portal-profile/' ),
        'resourcesUrl' => home_url( '/portal-resources/' ),
        'referralsUrl' => home_url( '/portal-referrals/' ),
        'loginUrl' => home_url( '/portal-login/' ),
        'registerUrl' => home_url( '/register/' ),
        'logoutUrl' => wp_logout_url( home_url( '/portal/' ) ),
        'mainSiteUrl' => home_url( '/' ),
        'currentPage' => $current_slug
    ] );
    
    error_log("Portal assets enqueued for page: {$current_slug}");
}, 100 );

require_once get_stylesheet_directory() . '/functions-portal-auth-session-fix.php';

// Load portal consolidation fix (page routing and template management)
require_once get_stylesheet_directory() . '/functions-portal-consolidation-fix.php';

// Load portal live auth fix (handles GoDaddy/shared hosting auth issues)
require_once get_stylesheet_directory() . '/functions-portal-auth-live-fix.php';

add_action('wp_footer', function() {
    if (current_user_can('manage_options') && isset($_GET['debug_portal'])) {
        error_log('[Portal Debug] Functions.php fully loaded, all portal files included');
        
        $current_slug = get_post_field('post_name', get_the_ID());
        error_log("[Portal Debug] Current page slug: {$current_slug}");
        
        // Check if portal.js was enqueued
        global $wp_scripts;
        $portal_loaded = isset($wp_scripts->registered['portal-js']);
        error_log("[Portal Debug] Portal JS registered: " . ($portal_loaded ? 'YES' : 'NO'));
    }
});

// migration to unified React app
require_once get_stylesheet_directory() . '/functions-react-unified.php';
