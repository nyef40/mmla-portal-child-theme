<?php
/**
 * Template Name: Dashboard
 * Description: User dashboard with stats and quick actions
 */

// At the top of page-profile.php, page-resources.php, etc.
portal_debug("TEMPLATE LOADED", [
    'template' => basename(__FILE__),
    'user_logged_in' => is_user_logged_in(),
    'request_uri' => $_SERVER['REQUEST_URI']
]);

// Before redirect logic
if (!is_user_logged_in() || (function_exists('user_has_portal_access_enhanced') && !user_has_portal_access_enhanced())) {
    portal_debug("REDIRECT TRIGGERED", [
        'reason' => !is_user_logged_in() ? 'not_logged_in' : 'no_portal_access',
        'redirect_to' => '/portal-login/'
    ]);
    wp_redirect(home_url('/portal-login/'));
    exit;
}

get_header(); 

$current_user = wp_get_current_user();
$user_id = get_current_user_id();
$first_name = get_user_meta($user_id, 'first_name', true);
$last_name = get_user_meta($user_id, 'last_name', true);
$practice_name = get_user_meta($user_id, 'practice_name', true);
$last_login = get_user_meta($user_id, 'last_login', true);
?>

<div class="portal-container">
    <div class="portal-content-area" style="padding: 40px 20px;">
        <!-- Welcome Header -->
        <div class="dashboard-header" style="background: linear-gradient(135deg, #0A3D62 0%, #1e5f8b 100%); color: white; padding: 40px; border-radius: 15px; margin-bottom: 40px; text-align: center;">
            <h1 style="margin: 0 0 10px 0; font-size: 2.5em;">Welcome back, <?php echo esc_html($first_name ?: $current_user->display_name); ?>!</h1>
            <p style="margin: 0; font-size: 1.2em; opacity: 0.9;">
                <?php if ($practice_name): ?>
                    <?php echo esc_html($practice_name); ?> • 
                <?php endif; ?>
                Last login: <?php echo $last_login ? date('M j, Y g:i A', strtotime($last_login)) : 'First time login'; ?>
            </p>
        </div>

        <!-- Stats Cards -->
        <div class="stats-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 25px; margin-bottom: 40px;">
            <div class="stat-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1); text-align: center; border-left: 5px solid #28a745;">
                <div style="font-size: 3em; color: #28a745; margin-bottom: 10px;">📋</div>
                <h3 style="color: #0A3D62; margin-bottom: 10px; font-size: 1.5em;">2</h3>
                <p style="color: #666; margin: 0;">Pending Referrals</p>
            </div>

            <div class="stat-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1); text-align: center; border-left: 5px solid #007bff;">
                <div style="font-size: 3em; color: #007bff; margin-bottom: 10px;">📚</div>
                <h3 style="color: #0A3D62; margin-bottom: 10px; font-size: 1.5em;">5</h3>
                <p style="color: #666; margin: 0;">Resources Accessed</p>
            </div>

            <div class="stat-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1); text-align: center; border-left: 5px solid #ffc107;">
                <div style="font-size: 3em; color: #ffc107; margin-bottom: 10px;">💬</div>
                <h3 style="color: #0A3D62; margin-bottom: 10px; font-size: 1.5em;">3</h3>
                <p style="color: #666; margin: 0;">New Messages</p>
            </div>

            <div class="stat-card" style="background: white; padding: 30px; border-radius: 15px; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1); text-align: center; border-left: 5px solid #17a2b8;">
                <div style="font-size: 3em; color: #17a2b8; margin-bottom: 10px;">👥</div>
                <h3 style="color: #0A3D62; margin-bottom: 10px; font-size: 1.5em;">12</h3>
                <p style="color: #666; margin: 0;">Active Patients</p>
            </div>
        </div>

        <!-- Quick Actions -->
        <div class="quick-actions" style="margin-bottom: 40px;">
            <h2 style="color: #0A3D62; margin-bottom: 25px; font-size: 1.8em;">Quick Actions</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                <a href="<?php echo home_url('/portal-referrals/'); ?>" class="action-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 3px 15px rgba(0, 0, 0, 0.1); text-decoration: none; color: inherit; transition: transform 0.3s ease, box-shadow 0.3s ease; display: block;">
                    <div style="font-size: 2.5em; color: #28a745; margin-bottom: 15px; text-align: center;">🏥</div>
                    <h3 style="color: #0A3D62; margin-bottom: 10px; text-align: center;">Submit Referral</h3>
                    <p style="color: #666; margin: 0; text-align: center; font-size: 0.9em;">Send a new patient referral</p>
                </a>

                <a href="<?php echo home_url('/portal-resources/'); ?>" class="action-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 3px 15px rgba(0, 0, 0, 0.1); text-decoration: none; color: inherit; transition: transform 0.3s ease, box-shadow 0.3s ease; display: block;">
                    <div style="font-size: 2.5em; color: #007bff; margin-bottom: 15px; text-align: center;">📖</div>
                    <h3 style="color: #0A3D62; margin-bottom: 10px; text-align: center;">View Resources</h3>
                    <p style="color: #666; margin: 0; text-align: center; font-size: 0.9em;">Access training materials</p>
                </a>

                <a href="<?php echo home_url('/profile/'); ?>" class="action-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 3px 15px rgba(0, 0, 0, 0.1); text-decoration: none; color: inherit; transition: transform 0.3s ease, box-shadow 0.3s ease; display: block;">
                    <div style="font-size: 2.5em; color: #6f42c1; margin-bottom: 15px; text-align: center;">👤</div>
                    <h3 style="color: #0A3D62; margin-bottom: 10px; text-align: center;">Update Profile</h3>
                    <p style="color: #666; margin: 0; text-align: center; font-size: 0.9em;">Manage your information</p>
                </a>

                <a href="<?php echo home_url('/contact/'); ?>" class="action-card" style="background: white; padding: 25px; border-radius: 12px; box-shadow: 0 3px 15px rgba(0, 0, 0, 0.1); text-decoration: none; color: inherit; transition: transform 0.3s ease, box-shadow 0.3s ease; display: block;">
                    <div style="font-size: 2.5em; color: #dc3545; margin-bottom: 15px; text-align: center;">📞</div>
                    <h3 style="color: #0A3D62; margin-bottom: 10px; text-align: center;">Contact Support</h3>
                    <p style="color: #666; margin: 0; text-align: center; font-size: 0.9em;">Get help and support</p>
                </a>
            </div>
        </div>

        <!-- Recent Activity -->
        <div class="recent-activity">
            <h2 style="color: #0A3D62; margin-bottom: 25px; font-size: 1.8em;">Recent Activity</h2>
            <div style="background: white; border-radius: 15px; box-shadow: 0 5px 20px rgba(0, 0, 0, 0.1); overflow: hidden;">
                <div class="activity-item" style="padding: 20px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center;">
                    <div style="width: 50px; height: 50px; background: #e3f2fd; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 1.5em;">📋</div>
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 5px 0; color: #0A3D62;">Referral Submitted</h4>
                        <p style="margin: 0; color: #666; font-size: 0.9em;">Patient: John Smith • 2 hours ago</p>
                    </div>
                    <span style="color: #28a745; font-weight: 600; font-size: 0.9em;">Pending</span>
                </div>

                <div class="activity-item" style="padding: 20px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center;">
                    <div style="width: 50px; height: 50px; background: #f3e5f5; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 1.5em;">📚</div>
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 5px 0; color: #0A3D62;">Resource Accessed</h4>
                        <p style="margin: 0; color: #666; font-size: 0.9em;">HIPAA Compliance Guide • Yesterday</p>
                    </div>
                    <span style="color: #007bff; font-weight: 600; font-size: 0.9em;">Completed</span>
                </div>

                <div class="activity-item" style="padding: 20px; border-bottom: 1px solid #f0f0f0; display: flex; align-items: center;">
                    <div style="width: 50px; height: 50px; background: #fff3e0; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 1.5em;">👤</div>
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 5px 0; color: #0A3D62;">Profile Updated</h4>
                        <p style="margin: 0; color: #666; font-size: 0.9em;">Contact information updated • 3 days ago</p>
                    </div>
                    <span style="color: #ffc107; font-weight: 600; font-size: 0.9em;">Updated</span>
                </div>

                <div class="activity-item" style="padding: 20px; display: flex; align-items: center;">
                    <div style="width: 50px; height: 50px; background: #ffebee; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-right: 15px; font-size: 1.5em;">💬</div>
                    <div style="flex: 1;">
                        <h4 style="margin: 0 0 5px 0; color: #0A3D62;">Message Received</h4>
                        <p style="margin: 0; color: #666; font-size: 0.9em;">Support team response • 1 week ago</p>
                    </div>
                    <span style="color: #17a2b8; font-weight: 600; font-size: 0.9em;">Read</span>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.action-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 25px rgba(0, 0, 0, 0.15);
}

@media (max-width: 768px) {
    .stats-grid {
        grid-template-columns: 1fr 1fr !important;
    }
    
    .dashboard-header h1 {
        font-size: 2em !important;
    }
    
    .dashboard-header p {
        font-size: 1em !important;
    }
}

@media (max-width: 480px) {
    .stats-grid {
        grid-template-columns: 1fr !important;
    }
}
</style>

<?php get_footer(); ?>


