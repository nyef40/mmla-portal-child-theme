<?php
/**
 * Template Name: Portal App Template
 * Description: Template for all portal pages (login, register, dashboard, profile, etc.)
 */

get_header();
?>

<main id="main" class="site-main portal-app-container">
    <div id="portal-root"></div>
    
    <noscript>
        <div style="padding: 40px; text-align: center; background: #fff3cd; border: 1px solid #ffc107; border-radius: 4px; margin: 20px;">
            <h2>JavaScript Required</h2>
            <p>This portal requires JavaScript to function. Please enable JavaScript in your browser settings.</p>
        </div>
    </noscript>
</main>

<?php
get_footer();

