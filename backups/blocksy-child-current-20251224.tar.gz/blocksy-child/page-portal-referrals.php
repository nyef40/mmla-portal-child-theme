<?php
/**
 * Template Name: Portal Referrals
 */

// At the top of page-profile.php, page-resources.php, etc.
portal_debug("TEMPLATE LOADED", [
    'template' => basename(__FILE__),
    'user_logged_in' => is_user_logged_in(),
    'request_uri' => $_SERVER['REQUEST_URI']
]);

// Before redirect logic
if (!is_user_logged_in() || (function_exists('user_has_portal_access_enhanced') && !user_has_portal_access_enhanced())) {
    portal_debug("REDIRECT TRIGGERED", [
        'reason' => !is_user_logged_in() ? 'not_logged_in' : 'no_portal_access',
        'redirect_to' => '/portal-login/'
    ]);
    wp_redirect(home_url('/portal-login/'));
    exit;
}
get_header(); ?>

<div class="portal-container">
    <div class="portal-referrals">
        <h1>My Referrals</h1>
        <p class="page-subtitle">View and manage your submitted patient referrals.</p>

        <div class="referral-list">
            <?php
            global $wpdb;
            $table_name = $wpdb->prefix . 'referral_submissions';
            $encryption_key = get_encryption_key(); // Assuming this function is available from functions.php

            // Fetch referrals submitted by the current logged-in user's email
            $current_user_email = wp_get_current_user()->user_email;

            // Note: This assumes provider_email is stored unencrypted for lookup.
            // If provider_email is also encrypted, you'd need a different lookup mechanism
            // or decrypt all records to find matches, which is inefficient.
            $referrals = $wpdb->get_results($wpdb->prepare(
                "SELECT * FROM {$table_name} WHERE provider_email = %s ORDER BY created_at DESC",
                $current_user_email
            ));

            if ($referrals) {
                echo '<table class="referral-table">';
                echo '<thead><tr><th>Date</th><th>Patient Name</th><th>Status</th><th>Details</th></tr></thead>';
                echo '<tbody>';
                foreach ($referrals as $referral) {
                    // Decrypt sensitive patient data
                    $patient_name_decrypted = $wpdb->get_var($wpdb->prepare(
                        "SELECT CAST(AES_DECRYPT(patient_name, %s) AS CHAR) FROM {$table_name} WHERE submission_id = %d",
                        $encryption_key, $referral->submission_id
                    ));
                    $patient_email_decrypted = $wpdb->get_var($wpdb->prepare(
                        "SELECT CAST(AES_DECRYPT(patient_email, %s) AS CHAR) FROM {$table_name} WHERE submission_id = %d",
                        $encryption_key, $referral->submission_id
                    ));
                    $insurance_decrypted = $wpdb->get_var($wpdb->prepare(
                        "SELECT CAST(AES_DECRYPT(insurance, %s) AS CHAR) FROM {$table_name} WHERE submission_id = %d",
                        $encryption_key, $referral->submission_id
                    ));

                    $status = $referral->is_validated ? 'Validated' : 'Pending Email Verification';
                    $status_class = $referral->is_validated ? 'status-validated' : 'status-pending';

                    echo '<tr>';
                    echo '<td>' . esc_html(date('M d, Y', strtotime($referral->created_at))) . '</td>';
                    echo '<td>' . esc_html($patient_name_decrypted) . '</td>';
                    echo '<td class="' . $status_class . '">' . esc_html($status) . '</td>';
                    echo '<td>';
                    echo '<button class="view-details-button" data-referral-id="' . esc_attr($referral->submission_id) . '">View Details</button>';
                    echo '<div id="details-' . esc_attr($referral->submission_id) . '" class="referral-details-modal" style="display:none;">';
                    echo '<h4>Referral Details for ' . esc_html($patient_name_decrypted) . '</h4>';
                    echo '<p><strong>Provider:</strong> ' . esc_html($referral->provider_name) . ' (' . esc_html($referral->provider_practice) . ')</p>';
                    echo '<p><strong>Provider Email:</strong> ' . esc_html($referral->provider_email) . '</p>';
                    echo '<p><strong>Provider Phone:</strong> ' . esc_html($referral->provider_phone) . '</p>';
                    echo '<p><strong>Patient Email:</strong> ' . esc_html($patient_email_decrypted) . '</p>';
                    echo '<p><strong>Patient Phone:</strong> ' . esc_html($referral->patient_phone) . '</p>';
                    echo '<p><strong>Insurance:</strong> ' . esc_html($insurance_decrypted) . '</p>';
                    echo '<p><strong>Reason:</strong> ' . esc_html($referral->reason) . '</p>';
                    echo '<p><strong>Notes:</strong> ' . esc_html($referral->notes) . '</p>';
                    echo '<p><strong>Status:</strong> <span class="' . $status_class . '">' . esc_html($status) . '</span></p>';
                    echo '<button class="close-details-button">Close</button>';
                    echo '</div>';
                    echo '</td>';
                    echo '</tr>';
                }
                echo '</tbody>';
                echo '</table>';
            } else {
                echo '<p class="no-referrals">You have not submitted any referrals yet.</p>';
                echo '<p><a href="/contact/" class="button button-primary">Submit a New Referral</a></p>';
            }
            ?>
        </div>
    </div>
</div>

<style>
.portal-referrals {
    max-width: 1000px;
    margin: 50px auto;
    padding: 40px;
    background: white;
    border-radius: 12px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    text-align: center;
}

.portal-referrals h1 {
    color: #0A3D62;
    font-size: 2.5rem;
    margin-bottom: 10px;
}

.page-subtitle {
    color: #666;
    font-size: 1.1rem;
    margin-bottom: 40px;
}

.referral-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 30px;
    box-shadow: 0 4px 15px rgba(0,0,0,0.05);
    border-radius: 8px;
    overflow: hidden; /* Ensures rounded corners apply to table content */
}

.referral-table th, .referral-table td {
    padding: 15px;
    border-bottom: 1px solid #eee;
    text-align: left;
}

.referral-table th {
    background-color: #0A3D62;
    color: white;
    font-weight: 600;
    text-transform: uppercase;
    font-size: 0.9rem;
}

.referral-table tbody tr:nth-child(even) {
    background-color: #f8f9fa;
}

.referral-table tbody tr:hover {
    background-color: #f0f4f7;
}

.status-validated {
    color: #28a745;
    font-weight: 600;
}

.status-pending {
    color: #ffc107;
    font-weight: 600;
}

.view-details-button {
    background: #0A3D62;
    color: white;
    border: none;
    padding: 8px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 0.9rem;
    transition: background-color 0.3s ease;
}

.view-details-button:hover {
    background-color: #1e5f8b;
}

.referral-details-modal {
    display: none; /* Hidden by default */
    position: fixed; /* Stay in place */
    z-index: 1000; /* Sit on top */
    left: 0;
    top: 0;
    width: 100%; /* Full width */
    height: 100%; /* Full height */
    overflow: auto; /* Enable scroll if needed */
    background-color: rgba(0,0,0,0.6); /* Black w/ opacity */
    display: flex;
    align-items: center;
    justify-content: center;
}

.referral-details-modal > div { /* The actual modal content */
    background-color: #fefefe;
    margin: auto;
    padding: 30px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
    max-width: 600px;
    width: 90%;
    position: relative;
    text-align: left;
}

.referral-details-modal h4 {
    color: #0A3D62;
    margin-top: 0;
    margin-bottom: 20px;
    font-size: 1.8rem;
}

.referral-details-modal p {
    margin-bottom: 10px;
    color: #333;
    line-height: 1.5;
}

.referral-details-modal p strong {
    color: #0A3D62;
}

.referral-details-modal .close-details-button {
    background: #dc3545;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 20px;
    float: right;
    transition: background-color 0.3s ease;
}

.referral-details-modal .close-details-button:hover {
    background-color: #c82333;
}

.no-referrals {
    font-size: 1.2rem;
    color: #888;
    margin-top: 50px;
}

.button-primary {
    padding: 12px 25px;
    background: linear-gradient(135deg, #0A3D62 0%, #1e5f8b 100%);
    color: white;
    border: none;
    border-radius: 8px;
    font-size: 1rem;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    text-decoration: none;
    display: inline-block;
    margin-top: 20px;
}

.button-primary:hover {
    transform: translateY(-2px);
    box-shadow: 0 8px 25px rgba(10, 61, 98, 0.3);
}

@media (max-width: 768px) {
    .portal-referrals {
        margin: 20px;
        padding: 30px 20px;
    }

    .referral-table {
        font-size: 0.9rem;
    }

    .referral-table th, .referral-table td {
        padding: 10px;
    }

    .referral-details-modal > div {
        padding: 20px;
    }
}
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelectorAll('.view-details-button').forEach(button => {
        button.addEventListener('click', function() {
            const referralId = this.dataset.referralId;
            const modal = document.getElementById('details-' + referralId);
            if (modal) {
                modal.style.display = 'flex'; // Show as flex to center
            }
        });
    });

    document.querySelectorAll('.close-details-button').forEach(button => {
        button.addEventListener('click', function() {
            const modal = this.closest('.referral-details-modal');
            if (modal) {
                modal.style.display = 'none';
            }
        });
    });

    // Close modal if clicked outside
    window.addEventListener('click', function(event) {
        document.querySelectorAll('.referral-details-modal').forEach(modal => {
            if (event.target === modal) {
                modal.style.display = 'none';
            }
        });
    });
});
</script>

<?php get_footer(); ?>
