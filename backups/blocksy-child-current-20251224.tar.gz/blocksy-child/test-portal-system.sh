#!/bin/bash
# Portal System Diagnostic Test Script
# Run this to verify all portal components are working

echo "=== Portal System Diagnostic ==="
echo ""

# 1. Check if portal template exists
echo "1. Checking portal template file..."
if [ -f "/var/www/html/wp-content/themes/blocksy-child/page-portal-final.php" ]; then
    echo "   ✓ page-portal-final.php exists"
else
    echo "   ✗ page-portal-final.php MISSING!"
fi

# 2. Check if portal.js bundle exists
echo ""
echo "2. Checking portal JavaScript bundle..."
if [ -f "/var/www/html/wp-content/themes/blocksy-child/portal/dist/portal.js" ]; then
    SIZE=$(stat -f%z "/var/www/html/wp-content/themes/blocksy-child/portal/dist/portal.js" 2>/dev/null || stat -c%s "/var/www/html/wp-content/themes/blocksy-child/portal/dist/portal.js")
    echo "   ✓ portal.js exists ($SIZE bytes)"
else
    echo "   ✗ portal.js MISSING!"
fi

# 3. Check portal pages in database
echo ""
echo "3. Checking portal pages in WordPress database..."
wp post list --post_type=page --post_name__in=portal,dashboard,portal-login,register --format=table --allow-root

# 4. Check which files are loaded in functions.php
echo ""
echo "4. Checking functions.php includes..."
grep -n "require_once.*portal" /var/www/html/wp-content/themes/blocksy-child/functions.php

# 5. Clear all caches
echo ""
echo "5. Clearing WordPress caches..."
wp cache flush --allow-root
wp transient delete --all --allow-root

echo ""
echo "=== Diagnostic Complete ==="
echo ""
echo "Next steps:"
echo "1. Visit http://localhost:8080/portal/ in your browser"
echo "2. Check debug log: docker exec -it mmla-portal-wordpress-1 tail -f /var/www/html/wp-content/debug.log"
echo "3. Look for: 'Portal page detected' and 'Portal assets enqueued'"
